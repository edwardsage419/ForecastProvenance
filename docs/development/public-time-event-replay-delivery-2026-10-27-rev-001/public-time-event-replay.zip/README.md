# 一次公开非预测时间演练：离线重放包（D245）

本包只保留D241单次已获准的NON_FORECAST_REHEARSAL：4次本地发送记录，2份有效回应，
2次自然超时；并提供原件、已核源码/二进制和官方公开root说明。没有私钥、Go测试密钥、
Go安装包/环境、venv、钱包、Core链数据或新的协议权限。没有合格provider状态或Genesis。

先核对单独留存的ZIP SHA256，再检查PUBLIC_EVENT_BUNDLE_MANIFEST.json里的每个原始成员。
清单不包含自身，不独立认证发布者/完整运行环境/必需历史全集。只展开到全新目录，
不得覆盖现有项目。历史运行脚本/authorization只是被审计的原件，不可拿来再次联网执行。

默认：使用已有兼容Python运行新目录内的现有passive入口，不安装任何依赖：

    /absolute/path/to/existing/python -I -S -B scripts/development/offline_evidence/roughtime_event.py

预期exit0及OBSERVED：47份固定输入、留存2有效回应/2超时、已用授权/后续状态对应。
这是原件与既有native审计的对应，本命令不重新执行native，也不发包；仍NOT_READY/NONE，
不是两个生产合格provider。已实际测试现有CPython3.12.3，其他解释器/OS未概括保证。

可选原生离线数学重放：仅darwin/arm64、使用包内原D238二进制，须禁止网络，例如macOS：

    /usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' /absolute/path/to/existing/python -I -S -B docs/development/public-time-event-replay-delivery-2026-10-27-rev-001/replay_public_event_portable.py

该driver复用原D241审计算法，补物理ROOT、原公开主体字节核对及结果存在即拒绝；协议算法不变。
原driver原字节仍保留。原source/binary/raw输入不变，派生关系记录在清单，不能冒充原compiled身份。
二进制所用固定上游及Go1.27.3许可原件见同目录UPSTREAM_NOTICES.md及列示路径。
新结果写入portable driver旁OFFLINE_REPLAY.json；已有文件/软链接先拒绝，最终排他创建，
不覆盖重放期间其他调用新建的结果，不产生新协议事件。
预期2份原回应验签、4个public signature/nonce变更反例拒绝及retry-state递推一致，发包数0。
网络拒绝不是整个OS/文件系统或恶意同UID进程隔离保证；软件独立信任仍未建立。

当前官方网页公开root/2002端点与两份回应对应；HTML仅材料，勿执行其中脚本或时钟API。
TimeNL历史Git文档点不证明90天连续运行；两个域/根/地址不证明root-secret或签发控制独立。
仍缺完整资格/权限/适用/历史、全部实际规则/报告/项目时间/Strong/workflow与G10。
不得重用本包已consumed授权、归零state、追加网络尝试、改pool/quorum或将演练改成预测。
