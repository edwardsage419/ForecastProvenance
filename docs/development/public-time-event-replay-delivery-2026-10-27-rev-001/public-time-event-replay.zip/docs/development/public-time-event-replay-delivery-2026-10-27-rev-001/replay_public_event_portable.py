"""Read/reverify retained public responses only; no transport or key generation."""
from pathlib import Path
from types import ModuleType
import json,hashlib,sys,base64
ROOT=Path(__file__).resolve().parents[3]
if (Path(__file__).resolve().parent/'OFFLINE_REPLAY.json').exists() or (Path(__file__).resolve().parent/'OFFLINE_REPLAY.json').is_symlink(): raise FileExistsError('refusing to overwrite existing offline replay result')
subject=ROOT/'docs/development/public-retention-exact-proposal-2026-10-26-rev-001/FILES.json'
current=ROOT
for part in subject.relative_to(ROOT).parts:
 current=current/part
 if current.is_symlink(): raise ValueError('public subject identity mismatch: symlink')
if not subject.is_file() or subject.stat().st_size!=41024: raise ValueError('public subject identity mismatch: size')
if hashlib.sha256(subject.read_bytes()).hexdigest()!='3731bc1ab028cad46ffeb3fcf79f9c116d3b6029647fa99d86f30c37f79db242': raise ValueError('public subject identity mismatch: hash')
OUT=Path(__file__).resolve().parent
PROPOSAL=ROOT/'docs/development/first-nonforecast-roughtime-exact-proposal-2026-10-27-rev-001'
AUTH='3ec15749be99e527c17644002b7ed36958c99594e54e7118a9c30e109360aa63'
EVENT=PROPOSAL/'run-evidence/events'/AUTH
identities=json.loads((PROPOSAL/'SOURCE_IDENTITIES.json').read_bytes())
sources={}
for row in identities:
 raw=(ROOT/row['path']).read_bytes()
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 sources[row['path']]=raw
package=ModuleType('forecast_trust_core');package.__path__=[];sys.modules[package.__name__]=package
order=['canonical','_roughtime_profile','_roughtime_control','_roughtime_support','_roughtime_plan','_roughtime_receipt','_roughtime_report','_verified_executable','_roughtime_execution']
loaded={}
for name in order:
 path='src/forecast_trust_core/'+name+'.py';m=ModuleType('forecast_trust_core.'+name);m.__package__='forecast_trust_core';m.__file__=str(ROOT/path);sys.modules[m.__name__]=m
 exec(compile(sources[path],m.__file__,'exec'),m.__dict__);loaded[name]=m
canonical=loaded['canonical'];control=loaded['_roughtime_control']
def read(name):return canonical.parse_json_strict((EVENT/name).read_bytes())
plan,auth,profile,before,after,report,trace=[read(n) for n in ['plan.json','authorization.json','verifier-build-profile.json','retry-state-before.json','retry-state-after.json','report.json','execution-transcript.json']]
assert auth['authorization_sha256']==AUTH
assert report['content_sha256']=='6dd4e12457d9e8c774b453cda2d18157b083666ad9420935a17b8de5ddf81dad'
assert (EVENT/'plan.json').read_bytes().strip()==canonical.canonical_json(json.loads((PROPOSAL/'PLAN_CANDIDATE.json').read_bytes()))
loaded['_roughtime_plan'].validate_authorization_record(auth,plan)
loaded['_roughtime_report'].validate_rehearsal_report(report,plan=plan,authorization=auth)
control.validate_report_control_binding(report,plan,auth,profile,before,after)
trace_core={k:v for k,v in trace.items() if k!='execution_transcript_sha256'}
assert hashlib.sha256(canonical.canonical_json(trace_core)).hexdigest()==trace['execution_transcript_sha256']==report['execution_transcript_sha256']
assert report['classification']=='NON_FORECAST_REHEARSAL' and report['prospective_eligible'] is False
backend=loaded['_roughtime_execution'].QualifiedVerifierBackend(ROOT/'docs/development/owner-roughtime-build-results.K0fixS/fpp-roughtime-strict',profile)
reconstructed=before;observations=[];positive=[];negative=[];sent=0;outbound=0;response_bytes=0
for provider,row in zip(plan['providers'],report['provider_results']):
 assert provider['provider_id']==row['provider_id']
 root_hash=hashlib.sha256(base64.b64decode(provider['root_public_key_base64'],validate=True)).hexdigest()
 prior_request=None
 for attempt in row['attempts']:
  directory=EVENT/'providers'/provider['provider_id']/('attempt-'+str(attempt['attempt_number']))
  request=(directory/'request.bin').read_bytes();transport=canonical.parse_json_strict((directory/'transport.json').read_bytes())
  assert len(request)==1036 and hashlib.sha256(request).hexdigest()==attempt['request_sha256']==(directory/'request.sha256').read_text().strip()
  assert base64.b64decode(attempt['request_base64'],validate=True)==request
  assert prior_request is None or prior_request==request
  prior_request=request
  reserved=canonical.parse_json_strict((directory/'retry-state-reserved.json').read_bytes())
  root=next(s for s in reserved['root_states'] if s['root_public_key_sha256']==root_hash)
  reconstructed=control.record_failure(reconstructed,root_hash,root['last_failure_unix_ms']);assert reconstructed==reserved
  assert transport['sent'] is True and transport['expected_host']==provider['host'] and transport['expected_port']==provider['port']
  sent+=1;outbound+=len(request)
  obs={'provider_id':provider['provider_id'],'attempt':attempt['attempt_number'],'transport_status':transport['transport_status'],'request_sha256':attempt['request_sha256'],'local_send_time':transport['send_utc'],'local_receive_time':transport['receive_utc'],'resolved_destination_is_local_observation_not_proof_of_external_route':True}
  if attempt['outcome']=='QUALIFYING_VERIFIED_RESPONSE':
   response=(directory/'response.bin').read_bytes();response_bytes+=len(response)
   assert base64.b64decode(attempt['response_base64'],validate=True)==response
   assert hashlib.sha256(response).hexdigest()==attempt['response_sha256']==(directory/'response.sha256').read_text().strip()
   assert transport['transport_status']=='RESPONSE'
   result=backend.verify_response(provider,request,response);assert result.verified is True and result.failure_code is None
   retained=canonical.parse_json_strict((directory/'verification.json').read_bytes());assert result.transcript==retained
   positive.append({'provider_id':provider['provider_id'],'response_sha256':attempt['response_sha256'],'midpoint_utc':result.midpoint_utc,'radius_nanoseconds':result.radius_nanoseconds,'native_replay_equal_retained_transcript':True})
   bad=bytearray(response);tags=int.from_bytes(response[12:16],'little');sig_start=12+4+(tags-1)*4+tags*4;bad[sig_start]^=1
   mutation=backend.verify_response(provider,request,bytes(bad));assert mutation.verified is False
   nonce=backend.verify_response(dict(provider,nonce_hex='00'*32),request,response);assert nonce.verified is False
   negative.append({'provider_id':provider['provider_id'],'changed_public_signature_rejected':True,'changed_signature_failure':mutation.failure_code,'wrong_nonce_rejected':True,'wrong_nonce_failure':nonce.failure_code})
   reconstructed=control.reset_root_state(reconstructed,root_hash)
  else:
   assert attempt['failure_code']=='TRANSPORT_TIMEOUT' and transport['transport_status']=='TIMEOUT'
   assert not (directory/'response.bin').exists()
  observations.append(obs)
assert reconstructed==after and sent==4 and outbound==4144 and len(positive)==2
assert report['qualifying_provider_count']==2 and report['final_rehearsal_status']=='REHEARSAL_VERIFIED'
assert (PROPOSAL/'run-evidence/consumed'/(AUTH+'.json')).is_file()
result={'classification':'OFFLINE_PUBLIC_EVENT_REPLAY_ONLY','report_content_sha256':report['content_sha256'],'authorization_sha256':AUTH,'execution_transcript_sha256':trace['execution_transcript_sha256'],'retained_request_response_and_transcript_bindings':'PASS','native_positive_replays':positive,'native_negative_replays':negative,'local_send_observations':observations,'local_sent_datagrams':sent,'outbound_application_payload_bytes':outbound,'response_payload_bytes':response_bytes,'retry_state_recomputed_from_reservations_and_verified_responses':'PASS','after_state_sha256':after['state_sha256'],'nonforecast_verified_response_count':len(positive),'production_qualified_provider_count_change':0,'real_project_forecast_time_evidence':False,'complete_qualification_history':False,'independent_control_domains_established':False,'operator_production_use_permission_established':False,'external_public_route_independently_observed':False,'new_network_requests':0,'real_admission':'NOT_READY','protocol_state_change':'NONE'}
with (OUT/'OFFLINE_REPLAY.json').open('x',encoding='utf-8') as replay_output:
 replay_output.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sent_observed':sent,'positive_native_replays':len(positive),'negative_native_replays':len(negative)*2,'outbound_payload_bytes':outbound,'state_reconstruction':'PASS'}))
