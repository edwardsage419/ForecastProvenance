# Bundled native verifier upstream notices

The retained D238 binary uses the pinned protocol package from tannerryan/roughtime v1.27.0, commit56b346a16cd7e8317bb0d24f1ec15549cf93a4c9. Its BSD2 notice is retained at scripts/genesis/roughtime_strict_verifier/pinned/roughtime/LICENSE. Source: https://github.com/tannerryan/roughtime/blob/56b346a16cd7e8317bb0d24f1ec15549cf93a4c9/LICENSE

The Go1.27.3 license notice is retained at docs/development/public-time-event-replay-delivery-2026-10-27-rev-001/GO1.27.3_LICENSE.txt. Exact source: https://github.com/golang/go/blob/go1.27.3/LICENSE, Git blob2a7cf70da6e498df9c11ab6a5eaa2ddd7af34da4. The Go archive/toolchain and its private test vectors are not included.
