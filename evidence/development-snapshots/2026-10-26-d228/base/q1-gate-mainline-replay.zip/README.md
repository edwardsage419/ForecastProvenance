# Forecast Provenance 当前Q1/gate离线开发版（D221）

本包补齐D218–D220增量及完整64声明gate输入；不是已就绪的真实协议。
在全新目录先核外部ZIP摘要、内部清单及安全普通相对成员，再用现有兼容环境运行：

    /absolute/path/to/existing/python -I -B scripts/development/offline_evidence/cli.py mainline --json
    /absolute/path/to/existing/python -I -B scripts/development/offline_evidence/cli.py demo --json

mainline预期exit1，14模块7局部OBSERVED/7MISSING、UNRESOLVED/NOT_READY/NONE；不是50%就绪。
包含2027Q1只读7目标候选/2GDP修订、3窗外前置日历对应，六CPI/U3时刻仍缺。
身份gate消费63声明输入/64准入快照；实际规则/权限/效力、完整runtime/软件信任、
四真实域报告、项目时间/资格历史/适用workflow与G10仍未建立。未执行原生验签。

环境不复制或安装。已测项目Python3.12.3/jsonschema4.26.0；PDF子进程复用现有
bundledPython3.12.14/pypdf6.10.0路径。其他机器须已有兼容环境，缺环境保留UNAVAILABLE。
不承诺跨平台、认证launcher或完整runtime/build闭包。catalog10cases/27inputs，demo5。

所有成员来自固定有限公共输入或固定公开wheel，不读取同名unknown dirty产品源码。
无私钥、owner公钥文件、语料、venv、钱包或链数据。adapter/dylib/历史控制脚本仅作材料，
勿手动执行历史命令；libsodium/private路径是公共头文件。原D204/D215交付保留。

运输清单只固定字节身份，不包含自身，不证明独立必需全集/实际权限。
21模块编译指纹含提取根，保留实际值并单独比较语义，不将指纹伪装为可搬迁身份。
只展开到全新目录，不覆盖已有工作。没有规范采纳、信任形成、资格、Acceptance、
Freeze、Genesis或任何生产/真实协议动作。
