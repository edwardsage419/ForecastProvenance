"""Two pinned public PDF observations, never official FIRST or admission.

This finite development consumer cannot establish authority, historical byte
immutability, authenticated time, applicability or complete mandatory history.
It neither creates nor verifies any protocol/signing message.
"""
from dataclasses import dataclass, field
from decimal import Decimal
from hashlib import sha256
from importlib.metadata import version
from io import BytesIO
import re
from types import MappingProxyType

from pypdf import PdfReader


class ObservationError(ValueError):
    pass


# Independently retained public bytes and manually inspected A38 page context.
# Values are parsed from the PDF, not selected from an expected-value table.
_EDITIONS = MappingProxyType({
    '2025-07': (
        '3cab42e98aae44f6e90678d75c7c028d1703729e95e1f1f91724519bacf42a84',
        39, 4, '2025-08-01', 'August 1, 2025', 'USDL-25-1202', 'JULY 2025',
        'July 2024 May 2025 June 2025 July 2025', '2025-06',
    ),
    '2025-11': (
        '6408e38172c272f3d8416f01873d3bc40d11c9ceb90933feb4939830cd63f6d2',
        42, 7, '2025-12-16', 'December 16, 2025', 'USDL-25-1581', 'NOVEMBER 2025',
        'Nov. 2024 Sept. 2025 Oct. 2025 Nov. 2025', '2025-10',
    ),
})


@dataclass(frozen=True)
class U3Observation:
    reference_month: str
    publication_date: str
    release_id: str
    display_value: str
    raw_sha256: str
    table_pdf_page: int
    column_values: tuple[str, ...]
    prior_reference_month: str
    prior_value: str | None
    prior_status: str
    parser_version: str
    evidence_class: str = field(default='ARCHIVAL_ISSUANCE_DECLARATION_ONLY', init=False)
    authenticated_availability: str = field(default='NOT_ESTABLISHED', init=False)


def observe_u3_pdf(raw: bytes, *, reference_month: str) -> U3Observation:
    """Observe exactly the retained issuance edition; reject caller re-pinning."""
    if type(raw) is not bytes or not raw:
        raise ObservationError('raw must be nonempty immutable bytes')
    if type(reference_month) is not str or reference_month not in _EDITIONS:
        raise ObservationError('reference month outside finite retained scope')
    digest, pages, page, date, date_label, release_id, title, columns, prior_month = _EDITIONS[reference_month]
    actual_digest = sha256(raw).hexdigest()
    if actual_digest != digest:
        raise ObservationError('raw identity does not match the retained issuance edition')
    parser_version = version('pypdf')
    if parser_version != '6.10.0':
        raise ObservationError('pypdf version differs from checked parser declaration')
    try:
        reader = PdfReader(BytesIO(raw), strict=True)
        if reader.is_encrypted or len(reader.pages) != pages:
            raise ObservationError('PDF retained structure mismatch')
        header = ' '.join(reader.pages[0].extract_text().split())
        table = reader.pages[page - 1].extract_text()
    except ObservationError:
        raise
    except Exception as exc:
        raise ObservationError('retained PDF extraction failed') from exc
    if not all(label in header for label in (date_label, release_id, title, 'EMPLOYMENT SITUATION')):
        raise ObservationError('issuance header context mismatch')
    flat = ' '.join(table.split())
    if not all(label in flat for label in (
        'HOUSEHOLD DATA', 'Summary table A. Household data, seasonally adjusted', columns,
    )):
        raise ObservationError('household table or reference columns mismatch')
    observed = []
    for label in ('Unemployment rate', 'Total, 16 years and over'):
        lines = [line for line in table.splitlines() if line.startswith(label + '.')]
        if len(lines) != 1:
            raise ObservationError('household rate row missing or ambiguous')
        cells = tuple(re.findall(r'[-−]?\d+\.\d+|[—–]', lines[0]))
        if len(cells) != 5:
            raise ObservationError('rate row column count mismatch')
        observed.append(cells)
    if observed[0] != observed[1]:
        raise ObservationError('household total rate rows disagree')
    cells = observed[0]
    value = cells[3]
    if not re.fullmatch(r'\d+\.\d+', value) or not 0 <= Decimal(value) <= 100:
        raise ObservationError('target rate missing or invalid')
    headlines = re.findall(r'unemployment rate,?\s+at (\d+\.\d+)\s+percent', header)
    if not headlines or any(item != value for item in headlines):
        raise ObservationError('headline and table rate disagree')
    prior = cells[2]
    if prior in ('–', '—'):
        if reference_month != '2025-11' or not all(label in flat for label in (
            'Data for October 2025 were not collected', 'federal government shutdown',
        )) or 'BLS did not publish an October 2025 Employment Situation news release' not in header:
            raise ObservationError('missing prior lacks retained context')
        prior_value, prior_status = None, 'SOURCE_DECLARED_NOT_COLLECTED'
    else:
        if not re.fullmatch(r'\d+\.\d+', prior) or not 0 <= Decimal(prior) <= 100:
            raise ObservationError('prior rate invalid')
        prior_value, prior_status = prior, 'SOURCE_DECLARED_VALUE'
    return U3Observation(reference_month, date, release_id, value, actual_digest, page,
                         cells, prior_month, prior_value, prior_status, parser_version)
