"""SYNTHETIC_TEST_ONLY keyless software inputs, no actual protocol evidence."""
import hashlib
import sys
from copy import deepcopy
from pathlib import Path
from types import ModuleType

OLD = Path(__file__).resolve().parent.parent / 'candidate-consumption'
def load(path, name, pin):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != pin:
        raise RuntimeError('Fixed test dependency changed')
    m = ModuleType(name); m.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), m.__dict__)
    return m
B = load(OLD/'consumer.py', '_b06_test_base', 'bf4f181f6661e1fea4ee9613931c532ea2e189cc3f0ae0e85fdcef93c2b25aff')
prior = sys.modules.get('canonical_helper')
sys.modules['canonical_helper'] = B._HELPER
try:
    T = load(OLD/'test_support.py', '_b06_old_keyless_test_utility', 'ca898d2ed5d266cc3d957b60f5f0cb3185095efcc3c76238882854c64e3d87fe')
finally:
    if prior is None: del sys.modules['canonical_helper']
    else: sys.modules['canonical_helper'] = prior
raw = B.canonical_json
ref = T.ref
digest = T.digest
external = lambda n: {'object_id': 'SYNTHETIC_TEST_ONLY:'+n, 'content_sha256': digest(n.encode())}
def seal(payload, kind, label):
    return B._HELPER.seal_object(payload, object_type=kind, stable_context='SYNTHETIC_TEST_ONLY', semantic_id='SYNTHETIC_TEST_ONLY:'+label)

def case(hooks=None, map_hook=None):
    hooks = hooks or {}; components={}; objects={}
    io = [{'role_id':'DATA', 'object_type':'Input', 'schema_version':'1.0'}]
    oo = [{'role_id':'RESULT', 'object_type':'Output', 'schema_version':'1.0'}]
    vocab = external('FAILURE_VOCAB')
    for suffix in ('A','B'):
        role='ROLE-'+suffix
        payload={'schema_version':'1.0','component_role':role,'contract_version':'DEV-1',
                 'operation_ids':['OP-'+suffix],'input_role_bindings':deepcopy(io),
                 'output_role_bindings':deepcopy(oo),'failure_vocabulary_ref':vocab,
                 'failure_precedence':['FAIL','UNKNOWN'],'determinism_requirement':'EXACT'}
        if role in hooks: hooks[role](payload)
        objects[role]=seal(payload,'ComponentContract','COMP-'+suffix)
        components[role]=raw(objects[role])
    operations=[]; entries=[]; coverage=[]; rows=[]
    for suffix in ('A','B'):
        op='OP-'+suffix; role='ROLE-'+suffix; cmd='cmd-'+suffix.lower()
        operations.append({'operation_id':op,'owning_component_role':role,
            'input_role_bindings':deepcopy(io),'output_role_bindings':deepcopy(oo),
            'implementation_entrypoint_id':'ENTRY-'+suffix,
            'failure_vocabulary_ref':vocab,'determinism_requirement':'EXACT'})
        entries.append({'operation_id':op,'logical_entrypoint_id':'ENTRY-'+suffix,
            'source_unit_ref':external('UNIT-'+suffix),'symbol':'consume_'+suffix.lower()})
        coverage.append({'operation_id':op,'command_ids':[cmd]})
        rows.append({'operation_id':op,'component_role':role,'logical_entrypoint_id':'ENTRY-'+suffix,
            'source_unit_ref':external('UNIT-'+suffix),'symbol':'consume_'+suffix.lower(),
            'command_ids':[cmd],'checks':[{'check_id':'CHECK-'+suffix,'command_ids':[cmd]}]})
    p={'schema_version':'1.0','registry_version':'DEV-1','operations':operations}
    if 'registry' in hooks: hooks['registry'](p)
    registry=seal(p,'OperationRegistry','REGISTRY')
    def tc(p):
        p.update({'command_declarations':[{'command_id':'cmd-a','argv':['python','safe_a.py']},
                                         {'command_id':'cmd-b','argv':['python','safe_b.py']}],
                  'operation_coverage':deepcopy(coverage)})
        if 'tc1' in hooks: hooks['tc1'](p)
    def ib(p):
        p['entrypoint_bindings']=deepcopy(entries)
        if 'ib' in hooks: hooks['ib'](p)
    def vc(p):
        p['operation_registry_ref']=ref(registry)
        p['component_contract_refs']=sorted([ref(o) for o in objects.values()], key=lambda r:(r['object_id'],r['content_sha256']))
        if 'vc' in hooks: hooks['vc'](p)
    base_expected, base_records=T.case({'tc1':tc,'ib':ib,'vc':vc,**{k:v for k,v in hooks.items() if k in ('tc2','r4t','runtime')}})
    mapping={'format':'FP_DEV_OPERATION_MAPPING_V1','scope':'FINITE_DEVELOPMENT_SCOPE_ONLY',
        'registry':{'ref':ref(registry),'version':'DEV-1'},
        'components':[{'role':role,'ref':ref(objects[role]),'version':'DEV-1'} for role in ('ROLE-A','ROLE-B')],
        'operations':rows}
    if map_hook: map_hook(mapping)
    m=raw(mapping)
    return [base_expected,base_records,m,digest(m),raw(registry),components]
