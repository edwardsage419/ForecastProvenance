"""Fresh-process public replay and identity refusal; no signing fixtures."""
import importlib.util
import unittest

if importlib.util.find_spec('replay'):
    import replay
else:
    replay = None


class ReplayTests(unittest.TestCase):
    def require(self):
        self.assertIsNotNone(replay, 'replay not implemented')
        return replay

    def test_complete_public_replay(self):
        module = self.require()
        result = module.run(module.HERE / 'PRE_RUN.json')
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['positive_verified'], 1)
        self.assertEqual(result['strict_rejected'], 913)
        self.assertEqual(result['failures'], [])
        self.assertEqual(result['missing'], [])
        self.assertFalse(result['prospective_eligible'])

    def test_binary_drift_refused(self):
        module = self.require()
        result = module.run(module.HERE / 'PRE_RUN.json', 'binary_hash_mismatch')
        self.assertEqual(result['status'], 'UNRESOLVED')
        self.assertTrue(result['native_load_refused'])
        self.assertIn('BINARY_IDENTITY_MISMATCH', result['reasons'])

    def test_arbitrary_input_refused(self):
        module = self.require()
        with self.assertRaises(ValueError):
            module.run(module.HERE / 'UNKNOWN.json')


if __name__ == '__main__':
    unittest.main()
