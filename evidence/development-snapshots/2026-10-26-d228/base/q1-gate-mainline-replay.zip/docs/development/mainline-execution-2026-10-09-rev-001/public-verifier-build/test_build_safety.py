"""Audit text fixtures test refusal paths, never substitute cryptographic success."""
import importlib.util
import unittest
from pathlib import Path

if importlib.util.find_spec('build'):
    import build
else:
    build = None


class BuildSafetyTests(unittest.TestCase):
    def test_unapproved_dependency_refused(self):
        self.assertTrue(hasattr(build, 'audit_dependencies'), 'dependency admission not implemented')
        with self.assertRaises(ValueError):
            build.audit_dependencies({'/tmp/unknown-header.h'}, Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk'))

    def audit(self, **changes):
        self.assertIsNotNone(build, 'binary audit not implemented')
        reports = dict(exports='_fp_dev_ed25519_verify_only\n',
                       undefined='_memcpy\n_memset\n___stack_chk_fail\n___stack_chk_guard\n',
                       libraries='binary:\n\t/usr/lib/libSystem.B.dylib (compatibility version 1.0.0, current version 1.0.0)\n',
                       load_commands='sectname __text\nsectname __data\n')
        reports.update(changes)
        return build.audit_reports(**reports)

    def test_allow_only_known_public_runtime(self):
        self.assertTrue(self.audit())

    def test_unknown_symbols_refused(self):
        for changes in [dict(exports='_fp_dev_ed25519_verify_only\n_crypto_sign\n'),
                        dict(undefined='_randombytes_buf\n'), dict(undefined='_unknown\n')]:
            with self.assertRaises(ValueError):
                self.audit(**changes)

    def test_library_and_initializer_refused(self):
        for changes in [dict(libraries='binary:\n\t/tmp/unknown.dylib (compatibility version 1)\n'),
                        dict(load_commands='sectname __mod_init_func\n'),
                        dict(load_commands='sectname __mod_term_func\n'),
                        dict(load_commands='flags SOME_INIT_ROUTINE\n')]:
            with self.assertRaises(ValueError):
                self.audit(**changes)


if __name__ == '__main__':
    unittest.main()
