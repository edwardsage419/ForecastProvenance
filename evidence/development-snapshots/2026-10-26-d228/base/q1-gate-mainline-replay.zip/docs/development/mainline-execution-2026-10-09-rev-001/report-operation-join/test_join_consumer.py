"""SYNTHETIC_TEST_ONLY keyless software checks; no real protocol inputs."""
import copy
import hashlib
import json
from pathlib import Path
from types import ModuleType
import unittest

HERE=Path(__file__).resolve().parent

def load(path,name,pin=None):
    raw=path.read_bytes()
    if pin and hashlib.sha256(raw).hexdigest()!=pin: raise RuntimeError("Fixed test source changed")
    m=ModuleType(name); m.__file__=str(path)
    exec(compile(raw,str(path),'exec'),m.__dict__)
    return m

H=load(HERE.parent/'operation-mapping/test_support.py','_b07_keyless',
       '47e7333a29c4216e315b6014a1a102ee122d2fbe54ea228bf1b4ae192e695688')
C=load(HERE.parent/'report-check-content/content_codec.py','_b07_fixture_codec',
       'dd264a7a3a753d258429bd78b4a38a679d94b52db2059e38442dc2aaef29d2c3')
J=load(HERE/'join_consumer.py','_b07_subject') if (HERE/'join_consumer.py').exists() else ModuleType('_missing_api')

def fixture(map_hook=None):
    args=H.case(map_hook=map_hook)
    mapping=json.loads(args[2]); reg=mapping['registry']['ref']
    catalog={'format':'FP_DEV_R6_CHECK_CATALOG_V1','scope':'FINITE_DEVELOPMENT_SCOPE_ONLY',
        'report_kind':'TRUST_CORE_TEST_REPORT','subject_ref':H.external('SUBJECT'),
        'validator_contract_ref':copy.deepcopy(args[0]['refs']['vc']),
        'content_profile_ref':H.external('CONTENT_PROFILE'),
        'checks':[{'check_id':'CHECK-'+x,'required_support_refs':[H.external('SUPPORT-'+x)],
          'required_coverage':[{'dimension':'OPERATION','member_ref':copy.deepcopy(reg)}]} for x in ('A','B')]}
    return args,catalog

def packed(args,catalog,statuses=None):
    raw=H.raw(catalog); pin=H.digest(raw); rows=[]
    for n in catalog['checks']:
        status=(statuses or {}).get(n['check_id'],'PASS')
        rows.append({'check_id':n['check_id'],'status':status,'reason_code':'SYNTHETIC_TEST_ONLY',
          'support_refs':copy.deepcopy(n['required_support_refs']),
          'coverage':copy.deepcopy(n['required_coverage']),'blocking_finding_refs':[]})
    return args+[raw,pin,C.build_checks(raw,pin,rows)]

class JoinTests(unittest.TestCase):
    def call(self,args):
        self.assertTrue(hasattr(J,'consume'),'Missing new join consume API')
        return J.consume(*args)
    def errors(self,result):return result['join_errors']
    def test_positive_binds_unique_checks_to_operations(self):
        a,c=fixture(); r=self.call(packed(a,c))
        self.assertEqual(r['local_join_verdict'],'LOCAL_REPORT_OPERATION_BINDINGS_VERIFIED')
        self.assertEqual([(x['check_id'],x['operation_id']) for x in r['joined_checks']], [('CHECK-A','OP-A'),('CHECK-B','OP-B')])
        self.assertEqual(r['joined_checks'][0]['registry_ref'],r['joined_checks'][1]['registry_ref'])
        self.assertEqual(r['verdict'],'UNRESOLVED'); self.assertEqual(len(r['real_missing']),29)
        self.assertFalse(r['prospective_eligible']); self.assertEqual(r['protocol_state_change'],'NONE')
    def test_catalog_is_legal_report_subset(self):
        a,c=fixture();c['checks']=c['checks'][1:];r=self.call(packed(a,c))
        self.assertEqual(r['local_join_verdict'],'LOCAL_REPORT_OPERATION_BINDINGS_VERIFIED')
        self.assertEqual([x['operation_id'] for x in r['joined_checks']],['OP-B'])
    def test_two_local_successes_do_not_bind_unmapped_report_check(self):
        def change(m):
            for x in m['operations']:x['checks'][0]['check_id']='OTHER-'+x['operation_id']
        a,c=fixture(change); r=self.call(packed(a,c))
        self.assertEqual(r['operation_result']['operation_binding_verdict'],'LOCAL_OPERATION_MAPPING_VERIFIED')
        self.assertTrue(r['content_result']['well_formed_and_bound'])
        self.assertIn('REPORT_CHECK_NOT_MAPPED',self.errors(r));self.assertEqual(r['verdict'],'REJECT')
    def test_validator_contract_mismatch(self):
        a,c=fixture(); c['validator_contract_ref']=H.external('OTHER_VC')
        self.assertIn('REPORT_VALIDATOR_MISMATCH',self.errors(self.call(packed(a,c))))
    def test_operation_coverage_wrong_registry(self):
        a,c=fixture();c['checks'][0]['required_coverage'][0]['member_ref']=H.external('OTHER_REGISTRY')
        self.assertIn('REPORT_OPERATION_COVERAGE_MISMATCH',self.errors(self.call(packed(a,c))))
    def test_operation_coverage_is_required(self):
        a,c=fixture();c['checks'][0]['required_coverage']=[]
        self.assertIn('REPORT_OPERATION_COVERAGE_MISMATCH',self.errors(self.call(packed(a,c))))
    def test_target_coverage_is_preserved(self):
        a,c=fixture();c['checks'][0]['required_coverage'].append({'dimension':'TARGET','member_ref':H.external('TARGET')})
        r=self.call(packed(a,c));self.assertEqual(r['local_join_verdict'],'LOCAL_REPORT_OPERATION_BINDINGS_VERIFIED')
    def test_wrong_wire_context_rejected(self):
        a,c=fixture();args=packed(a,c);args[-1][0]['report_context']['stage']='G5'
        r=self.call(args); self.assertTrue(r['content_result']['hard_errors']);self.assertEqual(r['verdict'],'REJECT')
    def test_missing_report_check_preserved(self):
        a,c=fixture();args=packed(a,c);args[-1].pop()
        r=self.call(args);self.assertEqual(r['content_result']['missing_checks'],['CHECK-B']);self.assertEqual(r['verdict'],'REJECT')
    def test_fail_unknown_and_missing_support_preserved(self):
        a,c=fixture();args=packed(a,c,{'CHECK-A':'FAIL','CHECK-B':'UNKNOWN'})
        args[-1][1]['support_refs']=[];args[-1][1]['missing_support_refs']=copy.deepcopy(c['checks'][1]['required_support_refs'])
        r=self.call(args);self.assertEqual(r['verdict'],'REJECT')
        self.assertEqual(r['content_result']['failed_checks'],['CHECK-A']);self.assertEqual(r['content_result']['unknown_checks'],['CHECK-B'])
        self.assertEqual(r['content_result']['missing_inputs'][0]['check_id'],'CHECK-B')
    def test_bad_catalog_preserves_base_missing(self):
        a,c=fixture();args=packed(a,c);args[1].pop('runtime');args[-2]='0'*64
        r=self.call(args);self.assertIn('CATALOG_INVALID',self.errors(r));self.assertIn('runtime',r['operation_result']['missing_inputs'])
    def test_bad_mapping_preserves_report_fail(self):
        a,c=fixture();args=packed(a,c,{'CHECK-A':'FAIL'});args[3]='0'*64
        r=self.call(args);self.assertEqual(r['content_result']['failed_checks'],['CHECK-A'])
        self.assertEqual(r['local_join_verdict'],'NOT_VERIFIED');self.assertFalse(r['joined_checks'])
    def test_extra_python_object_never_executes_and_later_failure_kept(self):
        class Trap:
            def __eq__(self,other):raise AssertionError('Trap equality invoked')
            def __deepcopy__(self,memo):raise AssertionError('Trap copy invoked')
        a,c=fixture();args=packed(a,c,{'CHECK-B':'FAIL'});args[-1][0]['report_context']=Trap()
        r=self.call(args);self.assertIn('INVALID_CHECK_ROW',self.errors(r));self.assertEqual(r['content_result']['failed_checks'],['CHECK-B'])
    def test_cyclic_check_row_rejected(self):
        a,c=fixture();args=packed(a,c);args[-1][0]['cycle']=args[-1][0]
        r=self.call(args);self.assertIn('INVALID_CHECK_ROW',self.errors(r))
    def test_root_checks_type_rejected(self):
        a,c=fixture();args=packed(a,c);args[-1]={};r=self.call(args)
        self.assertIn('INVALID_CHECKS',self.errors(r));self.assertEqual(r['content_result']['missing_checks'],['CHECK-A','CHECK-B'])
    def test_unknown_keeps_metadata_binding_without_readiness(self):
        a,c=fixture();r=self.call(packed(a,c,{'CHECK-A':'UNKNOWN'}))
        self.assertEqual(r['local_join_verdict'],'LOCAL_REPORT_OPERATION_BINDINGS_VERIFIED')
        self.assertEqual(r['content_result']['unknown_checks'],['CHECK-A']);self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_results_do_not_alias_input(self):
        a,c=fixture();args=packed(a,c);r=self.call(args)
        r['joined_checks'][0]['command_ids'].append('MUTATED')
        self.assertEqual(json.loads(args[2])['operations'][0]['checks'][0]['command_ids'],['cmd-a'])
    def test_top_level_diagnostics_do_not_alias_operation_branch(self):
        for field in ('real_missing','unverified_obligations'):
            with self.subTest(field=field):
                a,c=fixture();r=self.call(packed(a,c))
                retained=copy.deepcopy(r['operation_result'][field])
                r[field].clear()
                self.assertEqual(r['operation_result'][field],retained)
    def test_presigning_kind_is_not_four_r6(self):
        a,c=fixture();args=packed(a,c);c['report_kind']='PRE_SIGNING_BITCOIN_REPORT';args[-3]=H.raw(c);args[-2]=H.digest(args[-3])
        self.assertIn('CATALOG_INVALID',self.errors(self.call(args)))

if __name__=='__main__':unittest.main()
