"""SYNTHETIC_TEST_ONLY software fixtures; no real report, signing or protocol."""
import copy
import hashlib
import json
from pathlib import Path
from types import ModuleType
import unittest

HERE=Path(__file__).resolve().parent
def load(path,name,pin=None):
    raw=path.read_bytes()
    if pin and hashlib.sha256(raw).hexdigest()!=pin:raise RuntimeError('Fixed test dependency changed')
    m=ModuleType(name);m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__);return m
T=load(HERE.parent/'report-operation-join/test_join_consumer.py','_b08_keyless_test_helper',
       '4bc0d17f2778a384ea2db344e1dac4d7e5a7d80957aec3f8dbb4c6767d7924f0')
H=T.H
R=load(HERE/'report_consumer.py','_b08_subject') if (HERE/'report_consumer.py').exists() else ModuleType('missing')

def fixture(statuses=None,kind='TRUST_CORE_TEST_REPORT'):
    a,c=T.fixture();c['report_kind']=kind;packed=T.packed(a,c,statuses)
    deps=[c['content_profile_ref'],c['checks'][0]['required_coverage'][0]['member_ref']]
    deps.extend(x['required_support_refs'][0] for x in c['checks'])
    deps=sorted(copy.deepcopy(deps),key=lambda x:(x['object_id'],x['content_sha256']))
    vals=list((statuses or {}).values())
    result='INVALID' if 'FAIL' in vals else 'INELIGIBLE_TRUST_UNKNOWN' if 'UNKNOWN' in vals else 'VALID'
    payload={'schema_version':'2.0','validator_contract_ref':copy.deepcopy(c['validator_contract_ref']),
      'trusted_manifest_ref':copy.deepcopy(c['subject_ref']),'candidate_object_ref':copy.deepcopy(c['subject_ref']),
      'dependency_refs':deps,'result':result,'checks':packed[-1],'derived_claims':[]}
    report=H.seal(payload,'ValidationReport','REPORT')
    raw=H.raw(report)
    e={'format':'FP_DEV_R6_REPORT_EXPECTED_V1','scope':'FINITE_DEVELOPMENT_SCOPE_ONLY',
       'report_ref':H.ref(report),'report_raw_sha256':H.digest(raw),'subject_ref':copy.deepcopy(c['subject_ref']),
       'validator_contract_ref':copy.deepcopy(c['validator_contract_ref']),'report_kind':kind,
       'content_profile_ref':copy.deepcopy(c['content_profile_ref']),'dependency_refs':copy.deepcopy(deps)}
    return [e,raw,*a,packed[-3],packed[-2]]

def rewrite(args,change):
    obj=json.loads(args[1]);change(obj)
    payload={k:v for k,v in obj.items() if k not in ('object_type','object_id','payload_sha256','content_sha256')}
    obj=H.seal(payload,'ValidationReport','REPORT');args[1]=H.raw(obj)
    args[0]['report_ref']=H.ref(obj);args[0]['report_raw_sha256']=H.digest(args[1]);return args

class ReportTests(unittest.TestCase):
    def call(self,a):
        self.assertTrue(hasattr(R,'consume'),'Missing new full report consume API')
        return R.consume(*a)
    def reject(self,a,code):
        r=self.call(a);self.assertIn(code,r['report_errors']);self.assertEqual(r['verdict'],'REJECT');return r
    def test_four_kinds_bind_raw_full_subject_and_operations(self):
        for kind in ('TRUST_CORE_TEST_REPORT','GENESIS_ADVERSARIAL_REPORT','PROVIDER_REHEARSAL_REPORT','TARGET_SOURCE_PARSER_REPORT'):
            with self.subTest(kind=kind):
                r=self.call(fixture(kind=kind));self.assertEqual(r['local_report_binding_verdict'],'LOCAL_REPORT_CONTENT_BINDINGS_VERIFIED')
                self.assertEqual(r['aggregate_check_result'],'VALID');self.assertEqual(r['verdict'],'UNRESOLVED')
                self.assertEqual([x['operation_id'] for x in r['join_result']['joined_checks']],['OP-A','OP-B'])
                self.assertEqual(len(r['real_missing']),29);self.assertEqual(len(r['unverified_obligations']),11)
                self.assertFalse(r['prospective_eligible']);self.assertEqual(r['protocol_state_change'],'NONE')
    def test_reformatted_bytes_are_not_same_raw_identity(self):
        a=fixture();a[1]=json.dumps(json.loads(a[1]),indent=2).encode();self.reject(a,'REPORT_RAW_MISMATCH')
    def test_full_ref_substitution_rejected(self):
        a=fixture();a[0]['report_ref']=H.external('OTHER_REPORT');self.reject(a,'REPORT_REF_MISMATCH')
    def test_seal_tampering_does_not_hide_failed_checks(self):
        a=fixture({'CHECK-A':'FAIL'});obj=json.loads(a[1]);obj['payload_sha256']='0'*64;a[1]=H.raw(obj);a[0]['report_raw_sha256']=H.digest(a[1])
        r=self.reject(a,'REPORT_SEAL_INVALID');self.assertEqual(r['join_result']['content_result']['failed_checks'],['CHECK-A'])
    def test_duplicate_json_key_rejected(self):
        a=fixture();a[1]=b'{"checks":[],"checks":[]}';a[0]['report_raw_sha256']=H.digest(a[1]);self.reject(a,'INVALID_REPORT_JSON')
    def test_extra_top_field_rejected_while_unknown_retained(self):
        a=rewrite(fixture({'CHECK-B':'UNKNOWN'}),lambda r:r.update({'unexpected':'value'}))
        r=self.reject(a,'REPORT_SHAPE_INVALID');self.assertEqual(r['join_result']['content_result']['unknown_checks'],['CHECK-B'])
    def test_extra_integer_does_not_hide_fail_unknown_or_missing(self):
        for number in (0,1,-1):
            with self.subTest(number=number):
                a=rewrite(fixture({'CHECK-A':'FAIL','CHECK-B':'UNKNOWN'}),lambda r:r.update({'unexpected':number}))
                a[3].pop('runtime');r=self.reject(a,'REPORT_SHAPE_INVALID')
                self.assertIsNotNone(r['join_result'])
                self.assertEqual(r['join_result']['content_result']['failed_checks'],['CHECK-A'])
                self.assertEqual(r['join_result']['content_result']['unknown_checks'],['CHECK-B'])
                self.assertIn('runtime',r['operation_result']['missing_inputs'])
    def test_trusted_manifest_substitution_rejected(self):
        self.reject(rewrite(fixture(),lambda r:r.update({'trusted_manifest_ref':H.external('OTHER_MANIFEST')})),'REPORT_SUBJECT_MISMATCH')
    def test_candidate_subject_substitution_rejected(self):
        self.reject(rewrite(fixture(),lambda r:r.update({'candidate_object_ref':H.external('OTHER_MANIFEST')})),'REPORT_SUBJECT_MISMATCH')
    def test_report_validator_substitution_rejected(self):
        self.reject(rewrite(fixture(),lambda r:r.update({'validator_contract_ref':H.external('OTHER_VC')})),'REPORT_VALIDATOR_MISMATCH')
    def test_acceptance_ref_must_be_absent(self):
        self.reject(rewrite(fixture(),lambda r:r.update({'manifest_acceptance_ref':H.external('FUTURE_ACCEPTANCE')})),'PRESIGN_ACCEPTANCE_PRESENT')
    def test_null_acceptance_rejected_as_present(self):
        a=fixture();obj=json.loads(a[1]);obj['manifest_acceptance_ref']=None;a[1]=json.dumps(obj).encode();a[0]['report_raw_sha256']=H.digest(a[1])
        self.reject(a,'PRESIGN_ACCEPTANCE_PRESENT')
    def test_expected_kind_cannot_substitute_catalog(self):
        a=fixture();a[0]['report_kind']='PROVIDER_REHEARSAL_REPORT';self.reject(a,'REPORT_CATALOG_MISMATCH')
    def test_expected_profile_cannot_substitute_catalog(self):
        a=fixture();a[0]['content_profile_ref']=H.external('OTHER_PROFILE');self.reject(a,'REPORT_CATALOG_MISMATCH')
    def test_expected_subject_cannot_substitute_catalog(self):
        a=fixture();a[0]['subject_ref']=H.external('OTHER_SUBJECT');self.reject(a,'REPORT_CATALOG_MISMATCH')
    def test_expected_dependency_drift_rejected(self):
        a=fixture();a[0]['dependency_refs'].append(H.external('ZZ_OTHER'));self.reject(a,'REPORT_DEPENDENCIES_MISMATCH')
    def test_missing_dependency_even_if_expected_agrees_rejected(self):
        a=fixture();keep=a[0]['dependency_refs'][:-1];a[0]['dependency_refs']=copy.deepcopy(keep)
        a=rewrite(a,lambda r:r.update({'dependency_refs':keep}));self.reject(a,'REQUIRED_REPORT_DEPENDENCY_MISSING')
    def test_duplicate_report_dependency_rejected(self):
        a=rewrite(fixture(),lambda r:r['dependency_refs'].append(r['dependency_refs'][0]));self.reject(a,'REPORT_DEPENDENCIES_INVALID')
    def test_unsorted_report_dependency_rejected(self):
        a=rewrite(fixture(),lambda r:r['dependency_refs'].reverse());self.reject(a,'REPORT_DEPENDENCIES_INVALID')
    def test_wrong_report_context_subject_rejected(self):
        a=rewrite(fixture(),lambda r:r['checks'][0]['report_context'].update({'subject_ref':H.external('OTHER_SUBJECT')}))
        r=self.call(a);self.assertEqual(r['verdict'],'REJECT');self.assertTrue(r['join_result']['content_result']['hard_errors'])
    def test_report_check_omission_rejected(self):
        r=self.call(rewrite(fixture(),lambda r:r['checks'].pop()));self.assertEqual(r['verdict'],'REJECT');self.assertEqual(r['join_result']['content_result']['missing_checks'],['CHECK-B'])
    def test_valid_result_cannot_hide_fail(self):
        a=rewrite(fixture({'CHECK-A':'FAIL'}),lambda r:r.update({'result':'VALID'}));r=self.reject(a,'REPORT_RESULT_MISMATCH');self.assertEqual(r['aggregate_check_result'],'INVALID')
    def test_valid_result_cannot_hide_unknown(self):
        a=rewrite(fixture({'CHECK-B':'UNKNOWN'}),lambda r:r.update({'result':'VALID'}));r=self.reject(a,'REPORT_RESULT_MISMATCH');self.assertEqual(r['aggregate_check_result'],'INELIGIBLE_TRUST_UNKNOWN')
    def test_unknown_report_keeps_only_metadata_binding(self):
        r=self.call(fixture({'CHECK-B':'UNKNOWN'}));self.assertEqual(r['local_report_binding_verdict'],'LOCAL_REPORT_CONTENT_BINDINGS_VERIFIED');self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_derived_claim_verified_never_promotes_real_status(self):
        a=fixture();subject=a[0]['subject_ref']
        a=rewrite(a,lambda r:r['derived_claims'].append({'claim_type':'CONFIRMATORY_PROSPECTIVE_ELIGIBLE','subject_ref':subject,'state':'VERIFIED','policy_refs':[],'evidence_refs':[],'reason_codes':['SYNTHETIC_TEST_ONLY']}))
        r=self.call(a);self.assertEqual(r['derived_claims_verified'],'NOT_VERIFIED');self.assertEqual(len(r['unverified_derived_claims']),1);self.assertFalse(r['prospective_eligible']);self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_missing_body_is_unresolved_without_fake_empty_check_fail(self):
        a=fixture();a[1]=None;r=self.call(a);self.assertEqual(r['missing_report_inputs'],['report_bytes']);self.assertIsNone(r['join_result']);self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_bad_body_preserves_missing_runtime(self):
        a=fixture();a[1]=b'bad';a[3].pop('runtime');r=self.reject(a,'INVALID_REPORT_JSON');self.assertIn('runtime',r['operation_result']['missing_inputs'])
    def test_base_missing_and_report_fail_unknown_coexist(self):
        a=fixture({'CHECK-A':'FAIL','CHECK-B':'UNKNOWN'});a[3].pop('runtime');r=self.call(a)
        self.assertEqual(r['verdict'],'REJECT');self.assertIn('runtime',r['operation_result']['missing_inputs']);self.assertEqual(r['join_result']['content_result']['failed_checks'],['CHECK-A']);self.assertEqual(r['join_result']['content_result']['unknown_checks'],['CHECK-B'])
    def test_unknown_python_expected_never_executes(self):
        class Trap:
            def __eq__(self,o):raise AssertionError('custom equality invoked')
            def __deepcopy__(self,m):raise AssertionError('custom copy invoked')
        a=fixture({'CHECK-B':'UNKNOWN'});a[0]['subject_ref']=Trap();r=self.reject(a,'INVALID_REPORT_EXPECTED');self.assertEqual(r['join_result']['content_result']['unknown_checks'],['CHECK-B'])
    def test_serialized_final_lf_ref_rejected(self):
        a=rewrite(fixture(),lambda r:r['trusted_manifest_ref'].update({'object_id':r['trusted_manifest_ref']['object_id']+'\n'}));self.reject(a,'REPORT_REFERENCE_INVALID')
    def test_result_lists_and_input_are_isolated(self):
        a=fixture();saved=copy.deepcopy(a[0]);r=self.call(a);r['real_missing'].clear();r['operation_result']['unverified_obligations'].clear();r['join_result']['joined_checks'][0]['command_ids'].clear()
        self.assertEqual(len(r['join_result']['real_missing']),29);self.assertEqual(len(r['unverified_obligations']),11);self.assertEqual(a[0],saved)

if __name__=='__main__':unittest.main()
