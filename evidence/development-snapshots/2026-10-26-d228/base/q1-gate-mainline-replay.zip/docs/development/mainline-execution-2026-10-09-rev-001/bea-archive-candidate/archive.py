"""Development observation of retained BEA archive declarations, never FIRST.

Expected quarter/date are comparisons, not independent authority or time proof.
Only memory bytes are consumed; no formulas, macros or external relations run.
"""
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
import hashlib
import io
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
RID = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
TITLE = 'Table 1.1.1. Percent Change From Preceding Period in Real Gross Domestic Product'
UNIT = '[Percent] Seasonally adjusted at annual rates'


class ArchiveObservationError(ValueError):
    pass


@dataclass(frozen=True)
class ArchiveObservation:
    reference_quarter: str
    publication_date: str
    raw_lexical: str
    canonical_decimal: str
    raw_sha256: str
    sheet: str
    period_header_cell: str
    value_cell: str
    publication_claim: str
    file_creation_claim: str
    evidence_class: str = field(default='ARCHIVE_EDITION_DECLARATION_ONLY', init=False)
    historical_first_bytes: str = field(default='NOT_ESTABLISHED', init=False)
    authenticated_availability: str = field(default='NOT_ESTABLISHED', init=False)


def _xml(z, name):
    try:
        text = z.read(name).decode('utf-8-sig')
        if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
            raise ArchiveObservationError('XML declarations/entities forbidden')
        return ET.fromstring(text)
    except (KeyError, UnicodeError, ET.ParseError) as exc:
        raise ArchiveObservationError('XML missing, encoding or syntax invalid') from exc


def _audit(z):
    members = z.infolist()
    names = [i.filename for i in members]
    if len(names) != len(set(names)):
        raise ArchiveObservationError('duplicate ZIP member')
    if len(names) > 3000 or sum(i.file_size for i in members) > 128 * 1024 * 1024:
        raise ArchiveObservationError('ZIP expansion limit')
    for i in members:
        n = i.filename
        if n.startswith('/') or '\\' in n or ':' in n or any(p in ('.', '..') for p in n.split('/')):
            raise ArchiveObservationError('ZIP path forbidden')
        if i.flag_bits & 1:
            raise ArchiveObservationError('encrypted ZIP forbidden')
        if i.file_size > 16 * 1024 * 1024 or i.file_size > max(1, i.compress_size) * 200:
            raise ArchiveObservationError('ZIP expansion limit')
        if any(s in n.lower() for s in ('vba', 'macrosheet', 'externallink', 'embedding', 'activex')) or n.lower().endswith(('.exe', '.dll', '.js', '.py', '.sh')):
            raise ArchiveObservationError('active/macro/external ZIP part forbidden')
        if n.endswith('.rels'):
            root = _xml(z, n)
            if root.tag != f'{{{REL_NS}}}Relationships':
                raise ArchiveObservationError('XML relationship root invalid')
            if any(r.get('TargetMode') == 'External' for r in root):
                raise ArchiveObservationError('external relationship forbidden')


def _cells(root, strings):
    if root.tag != f'{{{NS}}}worksheet':
        raise ArchiveObservationError('XML worksheet root invalid')
    cells = {}
    rows = set()
    for row in root.findall(f'{{{NS}}}sheetData/{{{NS}}}row'):
        row_id = row.get('r')
        if not row_id or not re.fullmatch(r'[1-9][0-9]{0,6}', row_id) or int(row_id) > 1048576:
            raise ArchiveObservationError('XML row coordinate outside Excel bounds')
        if row_id in rows:
            raise ArchiveObservationError('duplicate worksheet row')
        rows.add(row_id)
        for c in row.findall(f'{{{NS}}}c'):
            ref = c.get('r', '')
            match = re.fullmatch(r'([A-Z]{1,3})([1-9][0-9]{0,6})', ref)
            if not match or match[2] != row_id or int(match[2]) > 1048576:
                raise ArchiveObservationError('XML cell coordinate invalid')
            _column_number(match[1])
            if ref in cells:
                raise ArchiveObservationError('duplicate cell')
            if c.find(f'{{{NS}}}f') is not None:
                raise ArchiveObservationError('formula in observed worksheet forbidden')
            vs = c.findall(f'{{{NS}}}v')
            if len(vs) > 1:
                raise ArchiveObservationError('XML duplicate cell value')
            value = vs[0].text if vs else None
            kind = c.get('t')
            if kind not in (None, 'n', 's', 'inlineStr', 'b', 'e', 'str', 'd'):
                raise ArchiveObservationError('unsupported cell type')
            if kind != 'inlineStr' and c.find(f'{{{NS}}}is') is not None:
                raise ArchiveObservationError('XML conflicting cell payload')
            if kind == 's':
                if value is None or len(value) > 8 or not re.fullmatch(r'0|[1-9][0-9]*', value) or int(value) >= len(strings):
                    raise ArchiveObservationError('XML shared string index invalid')
                value = strings[int(value)]
            elif kind == 'inlineStr':
                inline = c.findall(f'{{{NS}}}is')
                if len(inline) != 1 or vs:
                    raise ArchiveObservationError('XML inline string invalid')
                value = ''.join(t.text or '' for t in inline[0].iter(f'{{{NS}}}t'))
            cells[ref] = (value, kind)
    return cells


def _column_number(col):
    if not re.fullmatch(r'[A-Z]{1,3}', col):
        raise ArchiveObservationError('column coordinate length invalid')
    value = 0
    for c in col:
        value = value * 26 + ord(c) - ord('A') + 1
    if value > 16384:
        raise ArchiveObservationError('column coordinate outside Excel bounds')
    return value


def observe_archive_advance(raw: bytes, *, reference_quarter: str, publication_date: str) -> ArchiveObservation:
    if type(raw) is not bytes or not raw or len(raw) > 5 * 1024 * 1024:
        raise ArchiveObservationError('nonempty bounded public XLSX bytes required')
    if type(reference_quarter) is not str or not re.fullmatch(r'[0-9]{4}-Q[1-4]', reference_quarter):
        raise ArchiveObservationError('quarter must be YYYY-QN')
    if type(publication_date) is not str or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', publication_date):
        raise ArchiveObservationError('date must be YYYY-MM-DD')
    try:
        when = date.fromisoformat(publication_date)
    except ValueError as exc:
        raise ArchiveObservationError('date invalid') from exc
    # Explicit English source spelling, independent of local locale settings.
    months = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
    expected_publication = f'Data published {months[when.month - 1]} {when.day:02}, {when.year}'
    quarter = reference_quarter.replace('-', '')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            _audit(z)
            wb = _xml(z, 'xl/workbook.xml')
            sheets = wb.findall(f'{{{NS}}}sheets/{{{NS}}}sheet')
            chosen = [s for s in sheets if s.get('name') == 'T10101-Q']
            if len(chosen) != 1:
                raise ArchiveObservationError('unique quarterly table sheet required')
            rels = _xml(z, 'xl/_rels/workbook.xml.rels')
            ids = [r.get('Id') for r in rels]
            if None in ids or len(ids) != len(set(ids)):
                raise ArchiveObservationError('duplicate/missing relationship identity')
            matching = [r for r in rels if r.get('Id') == chosen[0].get(RID)]
            if len(matching) != 1 or not matching[0].get('Type', '').endswith('/worksheet'):
                raise ArchiveObservationError('worksheet relationship invalid')
            target = matching[0].get('Target', '')
            if not re.fullmatch(r'worksheets/[A-Za-z0-9_.-]+\.xml', target):
                raise ArchiveObservationError('worksheet relationship path forbidden')
            shared = _xml(z, 'xl/sharedStrings.xml')
            strings = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t')) for si in shared.findall(f'{{{NS}}}si')]
            cells = _cells(_xml(z, posixpath.join('xl', target)), strings)
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
        raise ArchiveObservationError('ZIP content invalid/unsupported') from exc
    def text(ref):
        value, kind = cells.get(ref, (None, None))
        if value is not None and kind not in ('s', 'inlineStr'):
            raise ArchiveObservationError('text label/header type required')
        return value
    if text('A1') != TITLE:
        raise ArchiveObservationError('quarterly table title mismatch')
    if text('A2') != UNIT:
        raise ArchiveObservationError('SAAR percent unit mismatch')
    if text('A5') != expected_publication:
        raise ArchiveObservationError('publication claim mismatch')
    covered = re.fullmatch(r'Quarterly data from ([0-9]{4}Q[1-4]) to ([0-9]{4}Q[1-4])', text('A3') or '')
    if not covered or covered[2] != quarter:
        raise ArchiveObservationError('range must end at requested quarter')
    periods = [(ref[:-1], text(ref)) for ref, (val, _) in cells.items() if re.fullmatch(r'[A-Z]+8', ref) and _column_number(ref[:-1]) >= 4 and val is not None]
    periods.sort(key=lambda p: _column_number(p[0]))
    if (not periods or any(not re.fullmatch(r'[0-9]{4}Q[1-4]', val) for _, val in periods)
            or len({val for _, val in periods}) != len(periods)
            or periods[0][1] != covered[1] or periods[-1][1] != quarter):
        raise ArchiveObservationError('quarter period headers invalid')
    selected = [col for col, value in periods if value == quarter]
    if len(selected) != 1:
        raise ArchiveObservationError('unique requested quarter period required')
    gdp_rows = [ref[1:] for ref, (value, kind) in cells.items() if re.fullmatch(r'A[1-9][0-9]*', ref) and value == '1' and kind in (None, 'n', 's', 'inlineStr') and (text('B' + ref[1:]) or '').strip() == 'Gross domestic product' and text('C' + ref[1:]) == 'A191RL']
    if len(gdp_rows) != 1:
        raise ArchiveObservationError('unique GDP line 1 / A191RL required')
    cell = selected[0] + gdp_rows[0]
    value, kind = cells.get(cell, (None, None))
    if value is None:
        raise ArchiveObservationError('GDP value missing')
    if kind not in (None, 'n') or not re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?', value):
        raise ArchiveObservationError('GDP numeric literal required')
    number = Decimal(value)
    canonical = '0' if number == 0 else format(number, 'f')
    if '.' in canonical:
        canonical = canonical.rstrip('0').rstrip('.')
    return ArchiveObservation(reference_quarter, publication_date, value, canonical,
                              hashlib.sha256(raw).hexdigest(), 'T10101-Q', selected[0] + '8', cell,
                              text('A5'), text('A6') or '')
