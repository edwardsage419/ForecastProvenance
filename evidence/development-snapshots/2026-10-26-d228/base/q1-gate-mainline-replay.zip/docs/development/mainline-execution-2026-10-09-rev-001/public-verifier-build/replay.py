"""Replay only the frozen, supplied public CCTV corpus in this development package."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import tempfile

import public_verifier

HERE = Path(__file__).resolve().parent
CORPUS = HERE.parent / 'public-verifier-evidence/CCTV/50a8ecf2a220f4c8bdc4f085789b8e85c26829e7/ed25519/ed25519vectors.json'
CORPUS_SHA = 'b38e84caf3e7e89170ff520292dbeae421b0a794c27408ce5ce973018fe3d7f9'
REJECT_FLAGS = {'low_order_A', 'low_order_R', 'non_canonical_A', 'non_canonical_R',
                'low_order_component_A', 'low_order_component_R'}
KNOWN_FLAGS = REJECT_FLAGS | {'low_order_residue', 'reencoded_k'}


def run(input_path, negative_case=None):
    if Path(input_path).resolve() != HERE / 'PRE_RUN.json':
        raise ValueError('Only fixed package PRE_RUN accepted')
    if negative_case not in (None, 'binary_hash_mismatch'):
        raise ValueError('Unknown negative case')
    pre = json.loads(public_verifier._read_regular(HERE / 'PRE_RUN.json'))
    if pre['expected'] != {'positive_numbers': [305], 'strict_negative_numbers': [n for n in range(914) if n != 305],
                           'positive_status': 'VERIFIED', 'negative_status': 'REJECTED'}:
        raise ValueError('Expected result drift')
    raw = public_verifier._read_regular(CORPUS)
    if hashlib.sha256(raw).hexdigest() != CORPUS_SHA or pre['corpus_sha256'] != CORPUS_SHA:
        raise ValueError('Corpus identity drift')
    records = json.loads(raw)
    if type(records) is not list or len(records) != 914:
        raise ValueError('Incomplete corpus')
    for number, record in enumerate(records):
        if set(record) != {'number', 'key', 'sig', 'msg', 'flags'} or record['number'] != number:
            raise ValueError('Corpus shape/number drift')
        flags = record['flags']
        if number == 305:
            if flags is not None:
                raise ValueError('Positive annotation drift')
        elif type(flags) is not list or not set(flags).issubset(KNOWN_FLAGS) or not REJECT_FLAGS.intersection(flags):
            raise ValueError('Unestablished strict rejection category')
        record['msg'].encode('ascii')
    if negative_case:
        record = records[305]
        # A deterministic mutation of already audited public binary bytes, never loaded.
        with tempfile.TemporaryDirectory(dir=HERE, prefix='replay-drift-') as tmp:
            root = Path(tmp)
            (root / 'native').mkdir()
            (root / 'native/fp_public_verify.dylib').write_bytes(
                public_verifier._read_regular(HERE / 'native/fp_public_verify.dylib') + b'public drift')
            original = public_verifier.HERE
            try:
                public_verifier.HERE = root
                outcome = public_verifier.verify_hex(record['key'], record['sig'], record['msg'].encode('ascii'))
            finally:
                public_verifier.HERE = original
        result = asdict(outcome)
        result.update(negative_case=negative_case, native_load_refused=(outcome.status == 'UNRESOLVED' and
                       'BINARY_IDENTITY_MISMATCH' in outcome.reasons), failures=[], missing=[])
        return result
    result = {'status': 'PASS', 'positive_verified': 0, 'strict_rejected': 0, 'failures': [], 'missing': [],
              'corpus_sha256': CORPUS_SHA, 'binary_sha256': public_verifier.EXPECTED_BINARY_SHA256,
              'real_authentication': 'NOT_ESTABLISHED', 'readiness': 'NOT_ESTABLISHED',
              'real_admission': 'NOT_READY', 'prospective_eligible': False, 'protocol_state_change': 'NONE'}
    for record in records:
        number = record['number']
        expected = 'VERIFIED' if number == 305 else 'REJECTED'
        outcome = public_verifier.verify_hex(record['key'], record['sig'], record['msg'].encode('ascii'))
        if outcome.status == 'UNRESOLVED':
            result['missing'].append({'number': number, 'reasons': list(outcome.reasons)})
        elif outcome.status != expected:
            result['failures'].append({'number': number, 'expected': expected, 'actual': outcome.status})
        elif expected == 'VERIFIED':
            result['positive_verified'] += 1
        else:
            result['strict_rejected'] += 1
    if result['failures']:
        result['status'] = 'FAIL'
    elif result['missing']:
        result['status'] = 'UNRESOLVED'
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--negative-case', choices=['binary_hash_mismatch'])
    args = parser.parse_args()
    result = run(args.input, args.negative_case)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['status'] == 'PASS' else 2)
