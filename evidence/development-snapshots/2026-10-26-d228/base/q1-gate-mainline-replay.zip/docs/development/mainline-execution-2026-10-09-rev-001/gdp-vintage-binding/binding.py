"""Passive, finite GDP vintage declaration binding; no protocol authority."""
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
import hashlib
import importlib.util
import io
from pathlib import Path
import re
import sys
import zipfile


class BindingError(ValueError):
    """Malformed or contradictory development evidence; not protocol rejection."""


class MissingEvidence(BindingError):
    """A required public carrier or requested source declaration is absent."""


def _archive_module():
    path = Path(__file__).resolve().parent.parent / 'bea-archive-candidate/archive.py'
    if hashlib.sha256(path.read_bytes()).hexdigest() != '50373d31f96100ef3716cbfbf19ad6647168e5bf853eb7d0d296ac38a5f6b5e8':
        raise BindingError('pinned passive archive dependency changed')
    spec = importlib.util.spec_from_file_location('_ml_b10_pinned_archive', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


_ARCHIVE = _archive_module()
NS = _ARCHIVE.NS
TITLE = 'Vintage History of Quarterly Gross Domestic Product (GDP) and Gross Domestic Income (GDI) Estimates'
STAGES = ('Advance', 'Second', 'Third', 'Revised')
MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


@dataclass(frozen=True)
class VintageObservation:
    reference_quarter: str
    stage: str
    publication_date: str
    raw_lexical: str
    canonical_decimal: str
    raw_sha256: str
    quarter_cell: str
    stage_cell: str
    value_cell: str
    date_cell: str
    release_date_claim: str
    sheet: str = field(default='Vintage History', init=False)
    evidence_class: str = field(default='CURRENT_OFFICIAL_RETROSPECTIVE_VINTAGE_DECLARATION_ONLY', init=False)
    historical_first_bytes: str = field(default='NOT_ESTABLISHED', init=False)
    authenticated_availability: str = field(default='NOT_ESTABLISHED', init=False)
    prospective_eligible: bool = field(default=False, init=False)
    protocol_state_change: str = field(default='NONE', init=False)


@dataclass(frozen=True)
class AdvanceBinding:
    vintage: VintageObservation
    archive: _ARCHIVE.ArchiveObservation
    evidence_class: str = field(default='SOURCE_DECLARATIONS_AGREE_ONLY', init=False)
    historical_first_bytes: str = field(default='NOT_ESTABLISHED', init=False)
    authenticated_availability: str = field(default='NOT_ESTABLISHED', init=False)
    prospective_eligible: bool = field(default=False, init=False)
    protocol_state_change: str = field(default='NONE', init=False)


def _carrier(raw, expected_sha256):
    if raw is None:
        raise MissingEvidence('public XLSX carrier missing')
    if type(raw) is not bytes or not raw or len(raw) > 5 * 1024 * 1024:
        raise BindingError('bounded nonempty public XLSX bytes required')
    if type(expected_sha256) is not str or not re.fullmatch(r'[0-9a-f]{64}', expected_sha256):
        raise BindingError('explicit lowercase SHA256 comparison required')
    digest = hashlib.sha256(raw).hexdigest()
    if digest != expected_sha256:
        raise BindingError('public carrier identity mismatch')
    return digest


def _parameters(reference_quarter, stage, publication_date):
    if type(reference_quarter) is not str or not re.fullmatch(r'[0-9]{4}-Q[1-4]', reference_quarter):
        raise BindingError('quarter must be YYYY-QN')
    if type(stage) is not str or stage not in STAGES:
        raise BindingError('explicit supported publication stage required')
    if type(publication_date) is not str or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', publication_date):
        raise BindingError('publication date must be YYYY-MM-DD')
    try:
        date.fromisoformat(publication_date)
    except ValueError as exc:
        raise BindingError('publication date invalid') from exc


def _plain_string(element):
    # The three retained carriers use single ordinary <t> strings. Reject
    # unsupported rich/phonetic/extension payloads, never flatten annotations.
    children = list(element)
    if (len(children) != 1 or children[0].tag != f'{{{NS}}}t'
            or list(children[0]) or (element.text or '').strip()
            or (children[0].tail or '').strip()):
        raise BindingError('plain ordinary string payload required')
    return children[0].text or ''


def _validated_cells(raw, sheet_name):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            _ARCHIVE._audit(z)
            workbook = _ARCHIVE._xml(z, 'xl/workbook.xml')
            if workbook.tag != f'{{{NS}}}workbook':
                raise BindingError('workbook root invalid')
            sheets = workbook.findall(f'{{{NS}}}sheets/{{{NS}}}sheet')
            chosen = [s for s in sheets if s.get('name') == sheet_name]
            if len(chosen) != 1:
                raise BindingError('unique requested sheet required')
            rels = _ARCHIVE._xml(z, 'xl/_rels/workbook.xml.rels')
            ids = [r.get('Id') for r in rels]
            if None in ids or len(ids) != len(set(ids)):
                raise BindingError('duplicate or missing relationship identity')
            matches = [r for r in rels if r.get('Id') == chosen[0].get(_ARCHIVE.RID)]
            if len(matches) != 1 or not matches[0].get('Type', '').endswith('/worksheet'):
                raise BindingError('worksheet relationship invalid')
            target = matches[0].get('Target', '')
            if not re.fullmatch(r'worksheets/[A-Za-z0-9_.-]+\.xml', target):
                raise BindingError('worksheet relationship path forbidden')
            shared = _ARCHIVE._xml(z, 'xl/sharedStrings.xml')
            if shared.tag != f'{{{NS}}}sst':
                raise BindingError('shared strings root invalid')
            if any(child.tag != f'{{{NS}}}si' for child in shared):
                raise BindingError('unsupported shared-string entry')
            strings = [_plain_string(si) for si in shared]
            worksheet = _ARCHIVE._xml(z, 'xl/' + target)
            for inline in worksheet.iter(f'{{{NS}}}is'):
                _plain_string(inline)
            return _ARCHIVE._cells(worksheet, strings)
    except (_ARCHIVE.ArchiveObservationError, zipfile.BadZipFile, RuntimeError, NotImplementedError, OSError) as exc:
        raise BindingError('passive XLSX parsing failed: ' + str(exc)) from exc


def _date_claim(text, stage):
    match = re.fullmatch(r'([A-Z][a-z]{2}) ([1-9][0-9]?), ([0-9]{4})( GDI not published)?', text or '')
    if not match or match[1] not in MONTHS or (match[4] and stage != 'Advance'):
        raise BindingError('release-date declaration invalid')
    try:
        return date(int(match[3]), MONTHS.index(match[1]) + 1, int(match[2])).isoformat()
    except ValueError as exc:
        raise BindingError('release-date declaration invalid') from exc


def observe_vintage(raw, *, expected_sha256, reference_quarter, stage, publication_date):
    """Bind a finite source-declared tuple, never a historical FIRST/time claim."""
    digest = _carrier(raw, expected_sha256)
    _parameters(reference_quarter, stage, publication_date)
    cells = _validated_cells(raw, 'Vintage History')

    def text(ref):
        value, kind = cells.get(ref, (None, None))
        if value is not None and kind not in ('s', 'inlineStr'):
            raise BindingError('text cell type required: ' + ref)
        return value

    if text('A1') != TITLE:
        raise BindingError('vintage table title mismatch')
    # Only quarter section labels define boundaries; selected-section headers
    # independently establish measure. Neither current order nor value selects.
    sections = []
    for ref in cells:
        if re.fullmatch(r'A[1-9][0-9]*', ref):
            value = text(ref)
            if value and re.fullmatch(r'[0-9]{4}Q[1-4]', value):
                sections.append((int(ref[1:]), value))
    sections.sort()
    selected = [n for n, q in sections if q == reference_quarter.replace('-', '')]
    if not selected:
        raise MissingEvidence('requested quarter declaration missing')
    if len(selected) != 1:
        raise BindingError('ambiguous quarter section')
    start = selected[0]
    end = min((n for n, _ in sections if n > start), default=1048577)
    headers = {f'E{start+1}':'Percent Change', f'B{start+2}':'Vintage', f'E{start+2}':'from Preceding Period', f'E{start+3}':'Real GDP', f'G{start+3}':'Release Date'}
    if any(text(ref) != expected for ref, expected in headers.items()):
        raise BindingError('selected section measure/header mismatch')
    rows = sorted({int(ref[1:]) for ref in cells if re.fullmatch(r'B[1-9][0-9]*', ref) and start+4 <= int(ref[1:]) < end})
    versions = {}
    seen_stage = False
    for row in rows:
        label = text(f'B{row}')
        if label is None:
            continue
        if label not in STAGES:
            raise BindingError('unsupported stage in selected section')
        claim = text(f'G{row}')
        when = _date_claim(claim, label)
        key = (label, when)
        if key in versions:
            raise BindingError('duplicate publication tuple')
        versions[key] = (row, claim)
        seen_stage |= label == stage
    chosen = versions.get((stage, publication_date))
    if chosen is None:
        if seen_stage:
            raise BindingError('requested stage publication-date mismatch')
        raise MissingEvidence('requested stage declaration missing')
    row, claim = chosen
    lexical = text(f'E{row}')
    if not lexical or len(lexical) > 64 or not re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?', lexical):
        raise BindingError('finite decimal Real GDP text required')
    value = Decimal(lexical)
    canonical = '0' if value == 0 else format(value, 'f')
    if '.' in canonical:
        canonical = canonical.rstrip('0').rstrip('.')
    return VintageObservation(reference_quarter, stage, publication_date, lexical, canonical, digest, f'A{start}', f'B{row}', f'E{row}', f'G{row}', claim)


def bind_advance(vintage_raw, archive_raw, *, vintage_sha256, archive_sha256, reference_quarter, publication_date):
    """Compare two real carriers' declarations; matching data is not admission."""
    vintage = observe_vintage(vintage_raw, expected_sha256=vintage_sha256, reference_quarter=reference_quarter, stage='Advance', publication_date=publication_date)
    _carrier(archive_raw, archive_sha256)
    # Protect the reused archive's label strings with this package's narrow
    # ordinary-string profile too; do not modify the sealed B04 dependency.
    _validated_cells(archive_raw, 'T10101-Q')
    try:
        archive = _ARCHIVE.observe_archive_advance(archive_raw, reference_quarter=reference_quarter, publication_date=publication_date)
    except _ARCHIVE.ArchiveObservationError as exc:
        raise BindingError('archive declaration mismatch: ' + str(exc)) from exc
    if vintage.canonical_decimal != archive.canonical_decimal:
        raise BindingError('actual-carrier Real GDP declarations disagree')
    return AdvanceBinding(vintage, archive)
