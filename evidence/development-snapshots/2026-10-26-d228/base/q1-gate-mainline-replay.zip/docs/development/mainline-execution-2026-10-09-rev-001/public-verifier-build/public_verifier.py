"""Standalone development math result. Never establishes FPP authentication."""
import ctypes
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat

try:
    from run_binding import EXPECTED_PRE_RUN_SHA256
except ImportError:
    EXPECTED_PRE_RUN_SHA256 = 'BINDING_UNAVAILABLE'

HERE = Path(__file__).resolve().parent
# Set once by the controlled build, after actual binary inspection, before crypto.
EXPECTED_BINARY_SHA256 = 'b11b0d8ac4a1cd8731aacd2ef9bcee3830b586d38979884dbed8d43354eb9c2a'
EXPECTED_BUILD_OBS_SHA256 = '06f185858191fbb747fcbdda80085abad921a30092e3af0e1057ec32c9771a3f'
EXPECTED_SOURCE_MANIFEST_SHA256 = 'd568d5c9da94999972c17f4cc3d410496d6ac62eb23c3d060dfc7668ae3a1957'
EXPECTED_CONFIG_SHA256 = 'b39e23fc4a3ca0d572d8abd54f63d912c5b46d5f03edfb025a8fce3d850f2c6a'
_loaded = {}
REQUIRED_PRE_RUN_FILES = {'extract_sources.py', 'test_extraction.py', 'test_build_safety.py',
                          'test_public_verifier.py', 'test_replay.py', 'bridge.c', 'public_verifier.py',
                          'build.py', 'replay.py', 'TEST_SPEC.md', 'SOURCE_MANIFEST.json', 'config.h',
                          'BUILD_OBSERVATIONS.json', 'evidence/DEPENDENCY_AUDIT.json'}


@dataclass(frozen=True)
class CryptoResult:
    status: str
    reasons: tuple[str, ...] = ()
    real_authentication: str = 'NOT_ESTABLISHED'
    readiness: str = 'NOT_ESTABLISHED'
    prospective_eligible: bool = False
    protocol_state_change: str = 'NONE'


class Unresolved(ValueError):
    pass


def _read_regular(path):
    """No leaf symlink; only package/public source files are read."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise Unresolved('NON_REGULAR_INPUT')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            return stream.read()
    finally:
        os.close(fd)


def _hash(raw):
    return hashlib.sha256(raw).hexdigest()


def _pinned(relative, expected, reason):
    raw = _read_regular(HERE / relative)
    if _hash(raw) != expected:
        raise Unresolved(reason)
    return raw


def _check_identity():
    binary = HERE / 'native/fp_public_verify.dylib'
    _pinned('native/fp_public_verify.dylib', EXPECTED_BINARY_SHA256, 'BINARY_IDENTITY_MISMATCH')
    observations = json.loads(_pinned('BUILD_OBSERVATIONS.json', EXPECTED_BUILD_OBS_SHA256,
                                      'BUILD_OBSERVATIONS_IDENTITY_MISMATCH'))
    manifest = json.loads(_pinned('SOURCE_MANIFEST.json', EXPECTED_SOURCE_MANIFEST_SHA256,
                                 'SOURCE_MANIFEST_IDENTITY_MISMATCH'))
    _pinned('config.h', EXPECTED_CONFIG_SHA256, 'CONFIG_IDENTITY_MISMATCH')
    if observations['binary_sha256'] != EXPECTED_BINARY_SHA256 or observations['audit'] != 'PASS':
        raise Unresolved('BINARY_AUDIT_NOT_ESTABLISHED')
    for entry in manifest['generated_files']:
        _pinned('generated/' + entry['path'], entry['raw_sha256'], 'GENERATED_SOURCE_IDENTITY_MISMATCH')
    source_root = HERE.parent / 'public-verifier-source/77e1ce5d6dee871c49ef211222ba18ef0c486bda/src/libsodium'
    for relative, expected in manifest['source_pins'].items():
        if _hash(_read_regular(source_root / relative)) != expected:
            raise Unresolved('ORIGINAL_SOURCE_IDENTITY_MISMATCH')
    # Freeze the development test/code inputs before first crypto execution.
    pre = json.loads(_pinned('PRE_RUN.json', EXPECTED_PRE_RUN_SHA256, 'PRE_RUN_IDENTITY_MISMATCH'))
    expected = {'positive_numbers': [305], 'strict_negative_numbers': [n for n in range(914) if n != 305],
                'positive_status': 'VERIFIED', 'negative_status': 'REJECTED'}
    if (pre['binary_sha256'] != EXPECTED_BINARY_SHA256 or pre['expected'] != expected or
        set(pre['package_pins']) != REQUIRED_PRE_RUN_FILES):
        raise Unresolved('PRE_RUN_BINDING_MISMATCH')
    for relative, expected in pre['package_pins'].items():
        _pinned(relative, expected, 'PRE_RUN_INPUT_IDENTITY_MISMATCH')
    return binary


def _load_verified_native():
    binary = _check_identity()  # Check on every call, including after cached load.
    cache_key = (str(binary), EXPECTED_BINARY_SHA256)
    if cache_key not in _loaded:
        library = ctypes.CDLL(str(binary))
        fn = library.fp_dev_ed25519_verify_only
        fn.argtypes = [ctypes.c_void_p, ctypes.c_size_t] * 3
        fn.restype = ctypes.c_int
        _loaded[cache_key] = (library, fn)
    return _loaded[cache_key][1]


def verify_hex(key_hex, signature_hex, message):
    if (type(key_hex) is not str or re.fullmatch('[0-9a-f]{64}', key_hex) is None or
        type(signature_hex) is not str or re.fullmatch('[0-9a-f]{128}', signature_hex) is None or
        type(message) is not bytes):
        return CryptoResult('INVALID_INPUT', ('STRICT_ENCODING_REQUIRED',))
    try:
        fn = _load_verified_native()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        reason = str(exc) if isinstance(exc, Unresolved) else type(exc).__name__
        return CryptoResult('UNRESOLVED', (reason,))
    a = ctypes.create_string_buffer(bytes.fromhex(key_hex))
    s = ctypes.create_string_buffer(bytes.fromhex(signature_hex))
    m = ctypes.create_string_buffer(message)
    result = fn(a, 32, s, 64, m, len(message))
    if result == 1:
        return CryptoResult('VERIFIED', ('STRICT_PURE_ED25519_MATH',))
    if result == 0:
        return CryptoResult('REJECTED', ('STRICT_POINT_OR_SIGNATURE_REJECTION',))
    return CryptoResult('UNRESOLVED', ('UNEXPECTED_NATIVE_RESULT',))
