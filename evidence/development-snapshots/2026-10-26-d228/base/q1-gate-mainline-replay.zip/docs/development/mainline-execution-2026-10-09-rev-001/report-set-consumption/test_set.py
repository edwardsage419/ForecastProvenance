"""SYNTHETIC_TEST_ONLY finite report-set interface, no real evidence/action."""
import copy
import hashlib
import json
from pathlib import Path
from types import ModuleType
import unittest
HERE=Path(__file__).resolve().parent
def load(p,name,pin=None):
    raw=p.read_bytes()
    if pin and hashlib.sha256(raw).hexdigest()!=pin:raise RuntimeError('Fixed set test dependency changed')
    m=ModuleType(name);m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);return m
T=load(HERE.parent/'full-report-consumption/test_report.py','_b09_keyless_helper',
       '4c08b496fd89d7532aaeb8be8ce907a049f61e6572ee6e16cd6b92d7cbbd1f8e')
H=T.H
S=load(HERE/'set_consumer.py','_b09_subject') if (HERE/'set_consumer.py').exists() else ModuleType('missing')
KINDS=('GENESIS_ADVERSARIAL_REPORT','PROVIDER_REHEARSAL_REPORT','TARGET_SOURCE_PARSER_REPORT','TRUST_CORE_TEST_REPORT')
BTC='OTS_BITCOIN_STRONG_VERIFICATION_REPORT'

def fixture(statuses=None,verified=True):
    r6={};catalogs={};reports=[];base=None
    for kind in KINDS:
        a=T.fixture(statuses if kind=='TRUST_CORE_TEST_REPORT' else None,kind)
        base=a[2:8];r6[kind]=a[0];catalogs[kind]={'bytes':a[8],'sha256':a[9]};reports.append({'kind':kind,'bytes':a[1]})
    vc=base[0]['refs']['vc'];r4t=base[0]['refs']['r4t']
    payload={'schema_version':'1.0','origin_class':'SYNTHETIC','prospective_eligible':False,
      'subject_ref':copy.deepcopy(r4t),'validator_contract_ref':copy.deepcopy(vc),
      'strong_verifier_contract_ref':H.external('STRONG_CONTRACT'),
      'external_time_evidence_bundle_ref':H.external('BUNDLE'),'ots_proof_ref':H.external('PROOF'),
      'bundle_sha256':H.digest(b'SYNTHETIC_TEST_ONLY_BUNDLE'),'proof_sha256':H.digest(b'SYNTHETIC_TEST_ONLY_PROOF'),
      'verification_mode':'OWNER_CONTROLLED_BITCOIN_CORE','bitcoin_header_time_role':'DURABILITY_ONLY_NOT_CIVIL_TIME_BOUND',
      'verified':verified}
    if verified:payload.update({'bitcoin_block_height':0,'bitcoin_block_hash':H.digest(b'SYNTHETIC_TEST_ONLY_BLOCK'),
      'bitcoin_header_sha256':H.digest(b'SYNTHETIC_TEST_ONLY_HEADER'),'node_version':'SYNTHETIC_TEST_ONLY'})
    else:payload['reason_code']='SYNTHETIC_TEST_ONLY_FAILURE'
    report=H.seal(payload,'StrongBitcoinVerificationReport','PREBITCOIN');raw=H.raw(report)
    strong={k:copy.deepcopy(payload[k]) for k in ('subject_ref','validator_contract_ref','strong_verifier_contract_ref',
      'external_time_evidence_bundle_ref','ots_proof_ref','bundle_sha256','proof_sha256','origin_class')}
    strong.update({'report_ref':H.ref(report),'report_raw_sha256':H.digest(raw)})
    reports.append({'kind':BTC,'bytes':raw})
    e={'format':'FP_DEV_REQUIRED_REPORT_SET_V1','scope':'FINITE_DEVELOPMENT_SCOPE_ONLY',
      'final_manifest_ref':copy.deepcopy(r6[KINDS[0]]['subject_ref']),'validator_contract_ref':copy.deepcopy(vc),
      'r4t_ref':copy.deepcopy(r4t),'r4t_raw_sha256':H.digest(base[1]['r4t']),
      'r6_expected':r6,'prebitcoin_expected':strong}
    return [e,reports,catalogs,*base]

def rewrite(args,kind,change):
    row=next(x for x in args[1] if x['kind']==kind);r=json.loads(row['bytes']);change(r)
    p={k:v for k,v in r.items() if k not in ('object_type','object_id','payload_sha256','content_sha256')}
    r=H.seal(p,'StrongBitcoinVerificationReport' if kind==BTC else 'ValidationReport','PREBITCOIN' if kind==BTC else 'REPORT')
    row['bytes']=H.raw(r);e=args[0]['prebitcoin_expected'] if kind==BTC else args[0]['r6_expected'][kind]
    e['report_ref']=H.ref(r);e['report_raw_sha256']=H.digest(row['bytes']);return args

class SetTests(unittest.TestCase):
    def call(self,a):
        self.assertTrue(hasattr(S,'consume'),'Missing new required report set consume API')
        return S.consume(*a)
    def reject(self,a,code):
        r=self.call(a);self.assertIn(code,r['set_errors']);self.assertEqual(r['verdict'],'REJECT');return r
    def trust(self,r):return next(x['result'] for x in r['entry_results'] if x['kind']=='TRUST_CORE_TEST_REPORT')
    def test_exact_five_bind_without_real_authority(self):
        r=self.call(fixture());self.assertEqual(r['local_set_binding_verdict'],'LOCAL_REQUIRED_REPORT_SET_BINDINGS_VERIFIED')
        self.assertEqual(r['verdict'],'UNRESOLVED');self.assertEqual(r['strong_truth'],'NOT_VERIFIED');self.assertEqual(r['report_stage_chronology'],'NOT_ESTABLISHED')
        self.assertEqual(len(r['real_missing']),29);self.assertEqual(len(r['unverified_obligations']),11);self.assertFalse(r['prospective_eligible']);self.assertEqual(r['protocol_state_change'],'NONE')
    def test_submission_order_is_not_role_identity(self):
        a=fixture();a[1].reverse();self.assertEqual(self.call(a)['local_set_binding_verdict'],'LOCAL_REQUIRED_REPORT_SET_BINDINGS_VERIFIED')
    def test_missing_kind_keeps_existing_unknown(self):
        a=fixture({'CHECK-B':'UNKNOWN'});a[1]=[x for x in a[1] if x['kind']!='PROVIDER_REHEARSAL_REPORT'];r=self.call(a)
        self.assertEqual(r['missing_report_kinds'],['PROVIDER_REHEARSAL_REPORT']);self.assertEqual(r['verdict'],'UNRESOLVED');self.assertEqual(self.trust(r)['join_result']['content_result']['unknown_checks'],['CHECK-B'])
    def test_none_report_bytes_is_missing(self):
        a=fixture();a[1][-1]['bytes']=None;r=self.call(a);self.assertEqual(r['missing_report_kinds'],[BTC]);self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_duplicate_does_not_hide_later_fail(self):
        a=fixture({'CHECK-A':'FAIL'});a[1].insert(0,copy.deepcopy(a[1][0]));r=self.reject(a,'DUPLICATE_REPORT_KIND');self.assertEqual(self.trust(r)['join_result']['content_result']['failed_checks'],['CHECK-A'])
    def test_extra_rfinalb_rejected(self):
        a=fixture();a[1].append({'kind':'RFINALB','bytes':b'SYNTHETIC_TEST_ONLY'});self.reject(a,'UNKNOWN_REPORT_KIND')
    def test_empty_reports_retains_exact_five_missing(self):
        a=fixture();a[1]=[];r=self.call(a);self.assertEqual(set(r['missing_report_kinds']),set(KINDS)|{BTC});self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_record_caller_pass_field_rejected(self):
        a=fixture();a[1][0]['verdict']='PASS';self.reject(a,'INVALID_REPORT_RECORD')
    def test_unknown_python_record_never_executes(self):
        class Trap:
            def __iter__(self):raise AssertionError('Trap iteration')
            def __deepcopy__(self,m):raise AssertionError('Trap copy')
        a=fixture({'CHECK-A':'FAIL'});a[1].insert(0,Trap());r=self.reject(a,'INVALID_REPORT_RECORD');self.assertEqual(self.trust(r)['join_result']['content_result']['failed_checks'],['CHECK-A'])
    def test_expected_scope_invalid(self):
        a=fixture();a[0]['scope']='ADOPTED';self.reject(a,'INVALID_SET_EXPECTED')
    def test_global_manifest_substitution_rejected(self):
        a=fixture();a[0]['final_manifest_ref']=H.external('OTHER_MANIFEST');self.reject(a,'SET_CONTEXT_MISMATCH')
    def test_global_vc_substitution_rejected(self):
        a=fixture();a[0]['validator_contract_ref']=H.external('OTHER_VC');self.reject(a,'SET_CONTEXT_MISMATCH')
    def test_expected_kind_slot_mismatch_rejected(self):
        a=fixture();a[0]['r6_expected'][KINDS[0]]['report_kind']=KINDS[1];self.reject(a,'SET_CONTEXT_MISMATCH')
    def test_reused_report_ref_rejected(self):
        a=fixture();a[0]['r6_expected'][KINDS[1]]['report_ref']=copy.deepcopy(a[0]['r6_expected'][KINDS[0]]['report_ref']);self.reject(a,'DUPLICATE_EXPECTED_REPORT_REF')
    def test_r4t_reformatted_raw_is_not_same_retained_input(self):
        a=fixture();a[4]['r4t']=json.dumps(json.loads(a[4]['r4t']),indent=2).encode();self.reject(a,'R4T_RAW_MISMATCH')
    def test_r4t_expected_fullref_substitution_rejected(self):
        a=fixture();a[0]['r4t_ref']=H.external('OTHER_R4T');self.reject(a,'SET_CONTEXT_MISMATCH')
    def test_missing_r4t_preserved_unresolved(self):
        a=fixture();a[4].pop('r4t');r=self.call(a);self.assertIn('r4t_bytes',r['missing_set_inputs']);self.assertIn('r4t',r['operation_result']['missing_inputs']);self.assertEqual(r['verdict'],'UNRESOLVED')
    def test_explicit_none_r4t_is_missing_without_mutating_input(self):
        a=fixture({'CHECK-B':'UNKNOWN'});a[4]['r4t']=None;r=self.call(a)
        self.assertEqual(r['verdict'],'UNRESOLVED');self.assertEqual(r['missing_set_inputs'],['r4t_bytes'])
        self.assertEqual(r['operation_result']['missing_inputs'],['r4t']);self.assertEqual(r['operation_result']['failures'],[])
        self.assertEqual(self.trust(r)['join_result']['content_result']['unknown_checks'],['CHECK-B'])
        self.assertTrue(all(x['result']['verdict']=='UNRESOLVED' for x in r['entry_results'] if x['kind'] in KINDS))
        self.assertIn('r4t',a[4]);self.assertIsNone(a[4]['r4t'])
    def test_strong_subject_substitution_rejected(self):
        self.reject(rewrite(fixture(),BTC,lambda r:r.update({'subject_ref':H.external('OTHER_R4T')})),'STRONG_EXPECTED_MISMATCH')
    def test_strong_vc_substitution_rejected(self):
        self.reject(rewrite(fixture(),BTC,lambda r:r.update({'validator_contract_ref':H.external('OTHER_VC')})),'STRONG_EXPECTED_MISMATCH')
    def test_strong_contract_bundle_proof_substitutions_rejected(self):
        for field in ('strong_verifier_contract_ref','external_time_evidence_bundle_ref','ots_proof_ref'):
            with self.subTest(field=field):self.reject(rewrite(fixture(),BTC,lambda r:r.update({field:H.external('OTHER_INPUT')})),'STRONG_EXPECTED_MISMATCH')
    def test_strong_digests_substitutions_rejected(self):
        for field in ('bundle_sha256','proof_sha256'):
            with self.subTest(field=field):self.reject(rewrite(fixture(),BTC,lambda r:r.update({field:'0'*64})),'STRONG_EXPECTED_MISMATCH')
    def test_strong_raw_reordering_rejected(self):
        a=fixture();a[1][-1]['bytes']=json.dumps(json.loads(a[1][-1]['bytes']),indent=2).encode();self.reject(a,'STRONG_RAW_MISMATCH')
    def test_strong_fullref_substitution_rejected(self):
        a=fixture();a[0]['prebitcoin_expected']['report_ref']=H.external('OTHER_REPORT');self.reject(a,'STRONG_REF_MISMATCH')
    def test_strong_seal_tamper_rejected(self):
        a=fixture();obj=json.loads(a[1][-1]['bytes']);obj['payload_sha256']='0'*64;a[1][-1]['bytes']=H.raw(obj);a[0]['prebitcoin_expected']['report_raw_sha256']=H.digest(a[1][-1]['bytes']);self.reject(a,'STRONG_SEAL_INVALID')
    def test_strong_false_keeps_r6_unknown_and_failed_report(self):
        r=self.call(fixture({'CHECK-B':'UNKNOWN'},False));self.assertEqual(r['verdict'],'REJECT');self.assertEqual(r['strong_reported_result'],'FAILED');self.assertEqual(self.trust(r)['join_result']['content_result']['unknown_checks'],['CHECK-B'])
    def test_unparseable_strong_is_not_reported_verified(self):
        a=fixture();a[1][-1]['bytes']=b'SYNTHETIC_TEST_ONLY_INVALID_JSON';r=self.reject(a,'INVALID_STRONG_JSON')
        self.assertEqual(r['strong_reported_result'],'NOT_REPORTED')
    def test_strong_boolean_height_not_an_integer(self):
        self.reject(rewrite(fixture(),BTC,lambda r:r.update({'bitcoin_block_height':True})),'STRONG_SHAPE_INVALID')
    def test_strong_header_role_cannot_be_civil_time(self):
        self.reject(rewrite(fixture(),BTC,lambda r:r.update({'bitcoin_header_time_role':'CIVIL_TIME_BOUND'})),'STRONG_SHAPE_INVALID')
    def test_bad_catalog_controls_keep_other_report_fail(self):
        a=fixture({'CHECK-A':'FAIL'});a[2].pop(KINDS[0]);r=self.reject(a,'INVALID_CATALOG_CONTROLS');self.assertEqual(self.trust(r)['join_result']['content_result']['failed_checks'],['CHECK-A'])
    def test_result_diagnostics_do_not_alias_entries_or_inputs(self):
        a=fixture();before=copy.deepcopy(a[0]);r=self.call(a);r['real_missing'].clear();r['operation_result']['unverified_obligations'].clear();t=self.trust(r)
        self.assertEqual(len(t['real_missing']),29);self.assertEqual(len(r['unverified_obligations']),11);self.assertEqual(a[0],before)

if __name__=='__main__':unittest.main()
