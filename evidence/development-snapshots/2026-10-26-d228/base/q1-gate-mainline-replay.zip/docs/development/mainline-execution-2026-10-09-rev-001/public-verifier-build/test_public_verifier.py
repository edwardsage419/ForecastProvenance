"""Only the explicitly supplied public CCTV corpus and deterministic public mutations."""
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).parent
CORPUS = HERE.parent / 'public-verifier-evidence/CCTV/50a8ecf2a220f4c8bdc4f085789b8e85c26829e7/ed25519/ed25519vectors.json'
CORPUS_SHA = 'b38e84caf3e7e89170ff520292dbeae421b0a794c27408ce5ce973018fe3d7f9'
spec = importlib.util.find_spec('public_verifier')
if spec:
    import public_verifier as verifier
else:
    verifier = None


def load_corpus():
    raw = CORPUS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != CORPUS_SHA:
        raise ValueError('Changed public corpus')
    return json.loads(raw)


def load_cctv_record(number):
    record = load_corpus()[number]
    assert record['number'] == number
    return record['key'], record['sig'], record['msg'].encode('ascii'), record['flags']


class PublicVerifierTests(unittest.TestCase):
    def require(self):
        self.assertIsNotNone(verifier, 'public-only verifier not implemented')
        return verifier

    def test_cctv_305_positive(self):
        module = self.require()
        key, sig, msg, flags = load_cctv_record(305)
        self.assertIsNone(flags)
        self.assertEqual(module.verify_hex(key, sig, msg).status, 'VERIFIED')

    def test_cctv_913_strict_negatives(self):
        module = self.require()
        rejection = {'low_order_A', 'low_order_R', 'non_canonical_A', 'non_canonical_R',
                     'low_order_component_A', 'low_order_component_R'}
        checked = 0
        for record in load_corpus():
            if record['number'] == 305:
                continue
            with self.subTest(number=record['number']):
                self.assertTrue(rejection.intersection(record['flags']))
                result = module.verify_hex(record['key'], record['sig'], record['msg'].encode('ascii'))
                self.assertEqual(result.status, 'REJECTED')
            checked += 1
        self.assertEqual(checked, 913)

    def test_invalid_transport(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        cases = [(key.upper(), sig, msg), (key + '00', sig, msg),
                 (key[:-2], sig, msg), (' ' + key, sig, msg),
                 ('g' * 64, sig, msg), (key, sig.upper(), msg),
                 (key, sig[:-2], msg), (key, sig + '00', msg),
                 (key, sig + '\n', msg), (key, sig, msg.decode('ascii')),
                 (key, sig, bytearray(msg)), (None, sig, msg)]
        for args in cases:
            with self.subTest(types=tuple(type(x).__name__ for x in args)):
                self.assertEqual(module.verify_hex(*args).status, 'INVALID_INPUT')

    def test_S_boundary(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        order = 2 ** 252 + 27742317777372353535851937790883648493
        for scalar in [order, order + 1, 2 ** 256 - 1]:
            changed = sig[:64] + scalar.to_bytes(32, 'little').hex()
            with self.subTest(boundary=scalar == order):
                self.assertEqual(module.verify_hex(key, changed, msg).status, 'REJECTED')

    def test_point_categories(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        identity = '01' + '00' * 31
        self.assertEqual(module.verify_hex(identity, sig, msg).status, 'REJECTED')
        self.assertEqual(module.verify_hex(key, identity + sig[64:], msg).status, 'REJECTED')
        for number in [0, 8, 14, 12]:
            a, s, m, _ = load_cctv_record(number)
            self.assertEqual(module.verify_hex(a, s, m).status, 'REJECTED')

    def test_existing_message_substitution(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        other = next(x for x in load_corpus() if x['msg'].encode('ascii') != msg)
        self.assertEqual(module.verify_hex(key, sig, other['msg'].encode('ascii')).status, 'REJECTED')

    def test_missing_backend(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        with tempfile.TemporaryDirectory(dir=HERE) as tmp, patch.object(module, 'HERE', Path(tmp)):
            self.assertEqual(module.verify_hex(key, sig, msg).status, 'UNRESOLVED')

    def test_backend_drift_no_load(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            root = Path(tmp)
            (root / 'native').mkdir()
            source = HERE / 'native/fp_public_verify.dylib'
            (root / 'native/fp_public_verify.dylib').write_bytes(source.read_bytes() + b'public drift')
            with patch.object(module, 'HERE', root), patch.object(ctypes, 'CDLL', side_effect=AssertionError('must not load')):
                result = module.verify_hex(key, sig, msg)
                self.assertEqual(result.status, 'UNRESOLVED')
                self.assertIn('BINARY_IDENTITY_MISMATCH', result.reasons)

    def test_config_drift_no_load(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            root = Path(tmp)
            (root / 'native').mkdir()
            for name in ['native/fp_public_verify.dylib', 'BUILD_OBSERVATIONS.json',
                         'SOURCE_MANIFEST.json', 'config.h']:
                shutil.copyfile(HERE / name, root / name)
            (root / 'config.h').write_text('#define ED25519_COMPAT 1\n')
            with patch.object(module, 'HERE', root), patch.object(ctypes, 'CDLL', side_effect=AssertionError('must not load')):
                result = module.verify_hex(key, sig, msg)
                self.assertEqual(result.status, 'UNRESOLVED')
                self.assertIn('CONFIG_IDENTITY_MISMATCH', result.reasons)

    def test_native_length_and_null_guard(self):
        module = self.require()
        fn = module._load_verified_native()
        self.assertEqual(fn(None, 0, None, 0, None, 0), -1)
        a = ctypes.create_string_buffer(bytes.fromhex(load_cctv_record(305)[0]))
        s = ctypes.create_string_buffer(bytes.fromhex(load_cctv_record(305)[1]))
        self.assertEqual(fn(a, 31, s, 64, None, 0), -1)
        self.assertEqual(fn(a, 32, s, 63, None, 0), -1)
        self.assertEqual(fn(a, 32, s, 64, None, 1), -1)

    def test_manifest_drift_no_load(self):
        module = self.require()
        key, sig, msg, _ = load_cctv_record(305)
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            root = Path(tmp)
            (root / 'native').mkdir()
            for name in ['native/fp_public_verify.dylib', 'BUILD_OBSERVATIONS.json', 'SOURCE_MANIFEST.json']:
                shutil.copyfile(HERE / name, root / name)
            (root / 'SOURCE_MANIFEST.json').write_bytes((root / 'SOURCE_MANIFEST.json').read_bytes() + b' ')
            with patch.object(module, 'HERE', root), patch.object(ctypes, 'CDLL', side_effect=AssertionError('must not load')):
                result = module.verify_hex(key, sig, msg)
                self.assertEqual(result.status, 'UNRESOLVED')
                self.assertIn('SOURCE_MANIFEST_IDENTITY_MISMATCH', result.reasons)

    def test_pre_run_omission_and_drift_no_load(self):
        module = self.require()
        original = module._read_regular
        pre = json.loads(original(HERE / 'PRE_RUN.json'))
        # Align all actual current file hashes before isolating record mutations.
        pre['package_pins'] = {name: hashlib.sha256(original(HERE / name)).hexdigest()
                               for name in pre['package_pins']}
        changed = []
        empty = json.loads(json.dumps(pre)); empty['package_pins'] = {}; changed.append(empty)
        omitted = json.loads(json.dumps(pre)); del omitted['package_pins']['TEST_SPEC.md']; changed.append(omitted)
        drift = json.loads(json.dumps(pre)); drift['local_untrusted_recorded_at'] = 'public record drift'; changed.append(drift)
        for record in changed:
            raw = (json.dumps(record, indent=2) + '\n').encode()
            def read(path):
                return raw if Path(path) == HERE / 'PRE_RUN.json' else original(path)
            with self.subTest(pin_count=len(record['package_pins'])), patch.object(module, '_read_regular', side_effect=read):
                with self.assertRaisesRegex(module.Unresolved, 'PRE_RUN_IDENTITY_MISMATCH'):
                    module._check_identity()  # Identity gate only; never CDLL or math.

    def test_missing_pre_run_unresolved(self):
        module = self.require()
        original = module._read_regular
        def read(path):
            if Path(path) == HERE / 'PRE_RUN.json':
                raise FileNotFoundError('missing public freeze record')
            return original(path)
        key, sig, msg, _ = load_cctv_record(305)
        with patch.object(module, '_read_regular', side_effect=read), patch.object(ctypes, 'CDLL', side_effect=AssertionError('must not load')):
            self.assertEqual(module.verify_hex(key, sig, msg).status, 'UNRESOLVED')

    def test_real_ceilings(self):
        module = self.require()
        for number in [305, 0]:
            key, sig, msg, _ = load_cctv_record(number)
            result = module.verify_hex(key, sig, msg)
            self.assertEqual(result.real_authentication, 'NOT_ESTABLISHED')
            self.assertEqual(result.readiness, 'NOT_ESTABLISHED')
            self.assertFalse(result.prospective_eligible)
            self.assertEqual(result.protocol_state_change, 'NONE')


if __name__ == '__main__':
    unittest.main()
