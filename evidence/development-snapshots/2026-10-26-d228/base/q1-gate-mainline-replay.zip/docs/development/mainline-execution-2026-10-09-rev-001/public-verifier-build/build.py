"""Direct compile and inspect pinned verification units. Never load the binary."""
import hashlib
import json
from pathlib import Path
import platform
import re
import shlex
import subprocess
import sys

import extract_sources

HERE = Path(__file__).resolve().parent
ALLOWED_UNDEFINED = {'_memcpy', '_memset', '_bzero', '___stack_chk_guard',
                     '___stack_chk_fail', 'dyld_stub_binder'}


def audit_reports(exports, undefined, libraries, load_commands):
    if set(exports.split()) != {'_fp_dev_ed25519_verify_only'}:
        raise ValueError('Unexpected exported API')
    if not set(undefined.split()).issubset(ALLOWED_UNDEFINED):
        raise ValueError('Unknown external symbol')
    deps = [line.strip().split(' (')[0] for line in libraries.splitlines()[1:] if line.strip()]
    # The first dependency is libSystem; no caller-controlled additional dylib.
    if deps != ['/usr/lib/libSystem.B.dylib']:
        raise ValueError('Unexpected dynamic dependency')
    if any(token in load_commands for token in
           ['__mod_init_func', '__mod_term_func', 'LC_ROUTINES', 'INIT_ROUTINE']):
        raise ValueError('Initializer/finalizer forbidden')
    return True


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_dependencies(paths, sdk):
    manifest = json.loads((HERE / 'SOURCE_MANIFEST.json').read_text())
    own = {str(HERE / 'generated' / entry['path']) for entry in manifest['generated_files']}
    own |= {str(HERE / 'config.h'), str(HERE / 'bridge.c')}
    roots = [str(sdk) + '/', '/Library/Developer/CommandLineTools/usr/lib/clang/17/include/']
    for path in paths:
        if path not in own and not any(path.startswith(root) for root in roots):
            raise ValueError('Unapproved compile dependency')
    return True


def read_dependencies(native):
    paths = set()
    for index in range(8):
        content = (native / f'unit{index}.d').read_text().replace('\\\n', '')
        paths.update(shlex.split(content.split(':', 1)[1]))
    return paths


def build():
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise ValueError('This approved build requires observed Darwin arm64')
    manifest = json.loads((HERE / 'SOURCE_MANIFEST.json').read_text())
    if manifest['source_pins'] != extract_sources.PINS:
        raise ValueError('Changed source manifest')
    for name, expected in extract_sources.PINS.items():
        extract_sources.validate_source(name, (extract_sources.SOURCE_ROOT / name).read_bytes())
    for entry in manifest['generated_files']:
        if sha(HERE / 'generated' / entry['path']) != entry['raw_sha256']:
            raise ValueError('Changed generated input')
    if (HERE / 'config.h').read_bytes() != extract_sources.CONFIG.encode():
        raise ValueError('Changed configuration')
    native = HERE / 'native'
    native.mkdir()  # Preserve existing unknown build output; never overwrite it.
    observations = {'development_only': True, 'commands': [], 'full_build_runtime_closure': 'NOT_ESTABLISHED',
                    'protocol_state_change': 'NONE', 'python_version': sys.version,
                    'python_executable': sys.executable, 'python_executable_sha256': sha(Path(sys.executable)),
                    'platform': platform.platform(), 'architecture': platform.machine()}

    def run(args, label):
        result = subprocess.run(args, cwd=HERE, text=True, capture_output=True, check=False)
        (native / (label + '.stdout.txt')).write_text(result.stdout)
        (native / (label + '.stderr.txt')).write_text(result.stderr)
        observations['commands'].append({'argv': args, 'label': label, 'exit_code': result.returncode})
        if result.returncode:
            (HERE / 'BUILD_FAILURE.json').write_text(json.dumps(observations, indent=2) + '\n')
            raise ValueError('Command failed: ' + label)
        return result.stdout

    observations['compiler_version'] = run(['/usr/bin/clang', '--version'], 'compiler_version')
    sdk = run(['/usr/bin/xcrun', '--show-sdk-path'], 'sdk_path').strip()
    if not Path(sdk).is_dir() or not sdk.startswith('/Library/Developer/CommandLineTools/SDKs/'):
        raise ValueError('SDK outside approved observed toolchain')
    observations['sdk_path'] = sdk
    observations['compiler_sha256'] = sha(Path('/usr/bin/clang'))
    observations['linker_version'] = run(['/usr/bin/ld', '-v'], 'linker_version')
    g = HERE / 'generated'
    common = ['/usr/bin/clang', '-O2', '-fPIC', '-fvisibility=hidden', '-Werror=implicit-function-declaration',
              '-isysroot', sdk, '-include', str(HERE / 'config.h'),
              '-I', str(g / 'include/sodium'), '-I', str(g / 'crypto_sign/ed25519/ref10')]
    units = [g / 'crypto_core/ed25519/ref10/ed25519_ref10.c',
             g / 'crypto_hash/sha512/cp/hash_sha512_cp.c', g / 'crypto_verify/verify.c',
             g / 'point_guard.c', g / 'hinit.c', g / 'detached.c', g / 'public_utils.c', HERE / 'bridge.c']
    macros = run(common + ['-E', '-dM', str(g / 'detached.c')], 'preprocessor_macros')
    names = dict(re.findall(r'^#define (\w+)(?: ([^\n]*))?$', macros, re.M))
    forbidden = ['ED25519_COMPAT', 'ED25519_NONDETERMINISTIC', 'CONFIGURED', 'HAVE_WEAK_SYMBOLS',
                 'HAVE_EMMINTRIN_H', 'HAVE_INLINE_ASM', 'NATIVE_BIG_ENDIAN', 'HAVE_MEMSET_S',
                 'HAVE_EXPLICIT_BZERO', 'HAVE_MEMSET_EXPLICIT', 'HAVE_EXPLICIT_MEMSET']
    if any(n in names for n in forbidden) or any(names.get(n) != '1' for n in
                                                   ['HAVE_TI_MODE', 'HAVE_GCC_MEMORY_FENCES', 'SODIUM_STATIC']):
        raise ValueError('Preprocessor branch mismatch')
    observations['macro_checks'] = {'forbidden_undefined': forbidden, 'fe_51': True, 'uint128_bytes': names.get('__SIZEOF_INT128__'),
                                   'portable_comparison': True, 'weak_disabled': True, 'configured_undefined': True}
    if names.get('__SIZEOF_INT128__') != '16':
        raise ValueError('Missing native uint128')
    objects = []
    for index, unit in enumerate(units):
        obj = native / f'unit{index}.o'
        run(common + ['-MD', '-MF', str(native / f'unit{index}.d'), '-c', str(unit), '-o', str(obj)], f'compile{index}')
        objects.append(str(obj))
    dependencies = read_dependencies(native)
    audit_dependencies(dependencies, Path(sdk))
    observations['compile_dependencies'] = sorted(dependencies)
    (native / 'exports.txt').write_text('_fp_dev_ed25519_verify_only\n')
    binary = native / 'fp_public_verify.dylib'
    run(['/usr/bin/clang', '-dynamiclib', '-isysroot', sdk, *objects,
         '-Wl,-dead_strip',
         '-Wl,-exported_symbols_list,' + str(native / 'exports.txt'),
         '-Wl,-install_name,@rpath/fp_public_verify.dylib', '-o', str(binary)], 'link')
    exports = run(['/usr/bin/nm', '-gUj', str(binary)], 'exports')
    undefined = run(['/usr/bin/nm', '-uj', str(binary)], 'undefined')
    libraries = run(['/usr/bin/otool', '-L', str(binary)], 'libraries')
    # otool includes the dylib's own install ID; remove only that exact observed entry.
    lines = libraries.splitlines()
    own = '\t@rpath/fp_public_verify.dylib (compatibility version 0.0.0, current version 0.0.0)'
    if len(lines) < 2 or lines[1] != own:
        raise ValueError('Unexpected dylib install ID')
    external_libraries = '\n'.join([lines[0], *lines[2:]])
    loads = run(['/usr/bin/otool', '-l', str(binary)], 'load_commands')
    audit_reports(exports, undefined, external_libraries, loads)
    observations.update(binary_sha256=sha(binary), exported_symbols=exports.split(),
                        undefined_symbols=undefined.split(), dynamic_libraries=['/usr/lib/libSystem.B.dylib'],
                        constructor_sections='NONE_OBSERVED', audit='PASS',
                        source_manifest_sha256=sha(HERE / 'SOURCE_MANIFEST.json'), config_sha256=sha(HERE / 'config.h'))
    observations['evidence_pins'] = {p.name: sha(p) for p in sorted(native.iterdir()) if p.is_file()}
    obs_path = HERE / 'BUILD_OBSERVATIONS.json'
    if obs_path.exists():
        raise FileExistsError('Preserve observations')
    obs_path.write_text(json.dumps(observations, indent=2) + '\n')
    frontend = HERE / 'public_verifier.py'
    code = frontend.read_text()
    pins = {'EXPECTED_BINARY_SHA256': sha(binary), 'EXPECTED_BUILD_OBS_SHA256': sha(obs_path),
            'EXPECTED_SOURCE_MANIFEST_SHA256': sha(HERE / 'SOURCE_MANIFEST.json'),
            'EXPECTED_CONFIG_SHA256': sha(HERE / 'config.h')}
    for name, value in pins.items():
        marker = name + " = 'BUILD_PENDING'"
        if code.count(marker) != 1:
            raise ValueError('Frontend pin state changed; no overwrite')
        code = code.replace(marker, name + " = '" + value + "'")
    frontend.write_text(code)
    binary.chmod(0o444)
    print('Actual binary audit PASS; no native load or crypto performed. Freeze PRE_RUN before execution.')


if __name__ == '__main__':
    build()
