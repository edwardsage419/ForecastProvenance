/* Development-only public verification. No init, keygen or signing calls. */
#include <stddef.h>
#include "crypto_core_ed25519.h"
#include "crypto_sign_ed25519.h"

__attribute__((visibility("default")))
int fp_dev_ed25519_verify_only(const unsigned char *A, size_t A_len,
                               const unsigned char *sig, size_t sig_len,
                               const unsigned char *msg, size_t msg_len)
{
    if (A == NULL || sig == NULL || A_len != 32 || sig_len != 64 ||
        (msg == NULL && msg_len != 0)) {
        return -1;
    }
    if (crypto_core_ed25519_is_valid_point(A) != 1 ||
        crypto_core_ed25519_is_valid_point(sig) != 1) {
        return 0;
    }
    return crypto_sign_ed25519_verify_detached(sig, msg,
                                              (unsigned long long) msg_len, A) == 0;
}
