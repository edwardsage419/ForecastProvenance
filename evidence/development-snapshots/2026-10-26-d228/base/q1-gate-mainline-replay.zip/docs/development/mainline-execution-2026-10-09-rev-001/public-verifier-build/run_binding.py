"""Frozen local development record identity; no protocol authority. Covered by FINAL_IDENTITIES.json, excluded from its own PRE_RUN to avoid self-hash recursion."""
EXPECTED_PRE_RUN_SHA256 = '4d30dd3de7aed5f14bb3641dd08d94fbf78b51af1349c908cb16a2afc83b5656'
