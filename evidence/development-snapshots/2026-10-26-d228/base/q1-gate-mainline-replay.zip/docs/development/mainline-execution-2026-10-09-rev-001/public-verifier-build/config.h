/* Development-only fixed configuration; not an upstream configured build. */
#ifndef FP_DEV_CONFIG_H
#define FP_DEV_CONFIG_H
#if defined(ED25519_COMPAT) || defined(ED25519_NONDETERMINISTIC) || defined(CONFIGURED)
#error Forbidden compatibility/signing/configured-build setting
#endif
#if defined(HAVE_WEAK_SYMBOLS) || defined(HAVE_EMMINTRIN_H) || defined(HAVE_INLINE_ASM)
#error Portable no-weak comparison required
#endif
#if defined(_WIN32) || defined(_MSC_VER) || defined(HAVE_MEMSET_S) || defined(HAVE_EXPLICIT_BZERO) || defined(HAVE_MEMSET_EXPLICIT) || defined(HAVE_EXPLICIT_MEMSET)
#error Volatile public-state memzero branch required
#endif
#if defined(NATIVE_BIG_ENDIAN) || defined(HAVE_C11_MEMORY_FENCES) || defined(HAVE_LIBCTGRIND)
#error Unexpected byte-order/fence/instrumentation setting
#endif
#if !defined(__SIZEOF_INT128__) || __SIZEOF_INT128__ != 16
#error fe_51 requires actual 128-bit integer support
#endif
#define HAVE_TI_MODE 1
#define HAVE_GCC_MEMORY_FENCES 1
#define SODIUM_STATIC 1
#endif
