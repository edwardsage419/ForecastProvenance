"""Extract only pinned public verification sources. No signing or key APIs run."""
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).parent
SOURCE_ROOT = HERE.parent / 'public-verifier-source' / '77e1ce5d6dee871c49ef211222ba18ef0c486bda' / 'src/libsodium'
PINS = {'crypto_core/ed25519/core_ed25519.c': 'd68770b35377d4c107b19c7bd415c2a8f20b0e92ae13c9d35240412da1f59858', 'crypto_core/ed25519/ref10/ed25519_ref10.c': '781f3f7b2cfaddfd9ba84ab177077c038df24074c974f445e6762d788de1fb9e', 'crypto_core/ed25519/ref10/fe_51/base.h': 'ed3ae74d98c89ac5a3aebada53e7ddb22d00c1968b7838d04a10665b4e651869', 'crypto_core/ed25519/ref10/fe_51/base2.h': '0e6cecfa1747abd6f7a09d6119b33cd435fb4b88ed3811bc002d81ccccfbd29c', 'crypto_core/ed25519/ref10/fe_51/constants.h': '6661adb3754c819987a75a03e44e2c478d260a06802dd1b7ec4e55281098dcc6', 'crypto_core/ed25519/ref10/fe_51/fe.h': '37352b6e254cf9c00b990f58825bd1013ac2157cf8b3786a9a664552fea546ea', 'crypto_hash/sha512/cp/hash_sha512_cp.c': '5b796efeaf882feda2e79c62d060d36208f2a469b52df9649c23b39253ca408b', 'crypto_sign/ed25519/ref10/open.c': 'cce38c5b716b867c150019af12af9f090c9b15c25165e0318907c585c753ea96', 'crypto_sign/ed25519/ref10/sign.c': 'b032204bad473385b028f76b0bbbe598d4c283c7b79e06aa296499491b47fea8', 'crypto_sign/ed25519/ref10/sign_ed25519_ref10.h': '1fec246674c8a39f8f3e0a2bd88713dd21bb02d6cb6b65a99b492148393ead79', 'crypto_verify/verify.c': '19539ba6a8485f602216a9728f72eb82c5eda6186eb8926758f17f50310bd4e8', 'include/sodium/crypto_core_ed25519.h': '47dfd3c6d59c9886dc36940916616ef4dc796aa5cb4b385eea7ecd0bf5406bb6', 'include/sodium/crypto_hash_sha512.h': 'b0d62c01d3fc61ec54b6bed58ed42b57602da3413979a34e285d8aab4472b8bf', 'include/sodium/crypto_sign_ed25519.h': 'c86e5a3ee60ee0140b5aef3b91bf59de809c6f8fec596663d96304f4280dcf19', 'include/sodium/crypto_verify_16.h': 'd3b4fbea4b6d2bf23a9a079939a181625be76a006af129732af86bf4b544456c', 'include/sodium/crypto_verify_32.h': '6ea1ea855b691a2b08510afe74f893d4ff44e40b14501d774d1a73dd79ad4e73', 'include/sodium/crypto_verify_64.h': '9736126e6d38864b7c2aa0edf0075e3f6b1fe485a060067ce8c06afb340171a8', 'include/sodium/export.h': 'acc6ee537f831d535b0607be90f05150103765b7ca82170fd61a85bd5e6f73ff', 'include/sodium/private/common.h': '9a652cc7be3ca2137e6126819bb403887c4d152b618be652be4708a618f18d3a', 'include/sodium/private/ed25519_ref10.h': '0acea90b49b5e8a0b83fe1757ef95f55c6b9c78fc63e8cc94e42ab5f6f222a14', 'include/sodium/private/ed25519_ref10_fe_51.h': '5945d563b602a6ef1efdcd3a542cbfe0a316dd0b58d29f6cc6a231aac12fe8d0', 'include/sodium/utils.h': 'c9a2e873da8d4c5fdfd004a821a2ec0550160d8b0bebd67517d53fe29d7269a8', 'sodium/utils.c': '54ed27fd5542d2f5d819b6104323a8c44c6c95e4e5c5766888b64f9dc67fc28d'}
CONFIG = r"""/* Development-only fixed configuration; not an upstream configured build. */
#ifndef FP_DEV_CONFIG_H
#define FP_DEV_CONFIG_H
#if defined(ED25519_COMPAT) || defined(ED25519_NONDETERMINISTIC) || defined(CONFIGURED)
#error Forbidden compatibility/signing/configured-build setting
#endif
#if defined(HAVE_WEAK_SYMBOLS) || defined(HAVE_EMMINTRIN_H) || defined(HAVE_INLINE_ASM)
#error Portable no-weak comparison required
#endif
#if defined(_WIN32) || defined(_MSC_VER) || defined(HAVE_MEMSET_S) || defined(HAVE_EXPLICIT_BZERO) || defined(HAVE_MEMSET_EXPLICIT) || defined(HAVE_EXPLICIT_MEMSET)
#error Volatile public-state memzero branch required
#endif
#if defined(NATIVE_BIG_ENDIAN) || defined(HAVE_C11_MEMORY_FENCES) || defined(HAVE_LIBCTGRIND)
#error Unexpected byte-order/fence/instrumentation setting
#endif
#if !defined(__SIZEOF_INT128__) || __SIZEOF_INT128__ != 16
#error fe_51 requires actual 128-bit integer support
#endif
#define HAVE_TI_MODE 1
#define HAVE_GCC_MEMORY_FENCES 1
#define SODIUM_STATIC 1
#endif
"""
MIXED = {'crypto_core/ed25519/core_ed25519.c', 'crypto_sign/ed25519/ref10/sign.c',
         'crypto_sign/ed25519/ref10/open.c', 'sodium/utils.c'}
FRAGMENTS = [
    ('crypto_core/ed25519/core_ed25519.c', 10, 23, 'point_guard.c'),
    ('crypto_sign/ed25519/ref10/sign.c', 11, 25, 'hinit.c'),
    ('crypto_sign/ed25519/ref10/open.c', 14, 66, 'detached.c'),
    ('sodium/utils.c', 122, 154, 'public_utils.c'),
    ('sodium/utils.c', 183, 205, 'public_utils.c'),
    ('sodium/utils.c', 254, 264, 'public_utils.c'),
]
HEADERS = {
    'point_guard.c': '#include "crypto_core_ed25519.h"\n#include "private/ed25519_ref10.h"\n',
    'hinit.c': '#include "crypto_hash_sha512.h"\n',
    'detached.c': '#include <limits.h>\n#include <stdint.h>\n#include <string.h>\n#include "crypto_hash_sha512.h"\n#include "crypto_sign_ed25519.h"\n#include "crypto_verify_32.h"\n#include "sign_ed25519_ref10.h"\n#include "private/common.h"\n#include "private/ed25519_ref10.h"\n#include "utils.h"\n',
    'public_utils.c': '#include <stddef.h>\n#include <stdint.h>\n#include "utils.h"\n',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def validate_source(name, raw):
    if name not in PINS or sha(raw) != PINS[name]:
        raise ValueError('Unapproved or changed public source: ' + name)


def prepare(destination):
    destination = Path(destination)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError('Preserve existing output')
    sources = {}
    for name in PINS:
        path = SOURCE_ROOT / name
        if not stat.S_ISREG(path.lstat().st_mode) or path.is_symlink():
            raise ValueError('Only fixed regular source files allowed')
        raw = path.read_bytes()
        validate_source(name, raw)
        sources[name] = raw
    # Validate every original before writing any output.
    outputs = {name: raw for name, raw in sources.items() if name not in MIXED}
    for name, header in HEADERS.items():
        outputs[name] = ('/* Fixed public helper extraction; see SOURCE_MANIFEST.json. */\n' + header).encode()
    fragments = []
    for name, first, last, output in FRAGMENTS:
        lines = sources[name].splitlines(keepends=True)
        segment = b''.join(lines[first - 1:last])
        outputs[output] += b'\n' + segment
        fragments.append({'source': name, 'first_line': first, 'last_line': last,
                          'segment_sha256': sha(segment), 'output': output})
    outputs['config.h'] = CONFIG.encode()
    destination.mkdir(parents=True)
    for name, raw in outputs.items():
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    return {'development_only': True, 'upstream_commit': '77e1ce5d6dee871c49ef211222ba18ef0c486bda',
            'source_pins': PINS, 'fragments': fragments,
            'generated_files': [{'path': name, 'raw_sha256': sha(raw)} for name, raw in sorted(outputs.items())],
            'excluded_translation_unit_paths': sorted(MIXED),
            'full_build_runtime_closure': 'NOT_ESTABLISHED', 'protocol_state_change': 'NONE'}


if __name__ == '__main__':
    manifest = prepare(HERE / 'generated')
    (HERE / 'SOURCE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (HERE / 'config.h').write_text(CONFIG)
    print('Pinned extraction complete; no code compiled or executed')
