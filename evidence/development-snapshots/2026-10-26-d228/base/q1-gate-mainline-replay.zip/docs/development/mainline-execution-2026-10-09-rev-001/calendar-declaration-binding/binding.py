"""Finite public calendar declarations; never protocol authority or completeness."""
import hashlib
import re
from datetime import datetime
from html.parser import HTMLParser

SELECTION = [{'quarter': '2025-Q3', 'stage': 'Initial', 'year': 2025, 'wall_label': 'December 23 8:30 AM', 'utc_declared': '20251223T133000Z', 'uid': '75eb47e4-33d7-492e-9581-94e97186b70f', 'title': 'Gross Domestic Product, 3rd Quarter 2025 (Initial Estimate) and Corporate Profits (Preliminary)', 'release_locator': '/news/2025/gross-domestic-product-3rd-quarter-2025-initial-estimate-and-corporate-profits'}, {'quarter': '2025-Q3', 'stage': 'Updated', 'year': 2026, 'wall_label': 'January 22 8:30 AM', 'utc_declared': '20260122T133000Z', 'uid': '2757488a-8cdc-4c45-a5ad-672c965745f0', 'title': 'Gross Domestic Product, 3rd Quarter 2025 (Updated Estimate), GDP by Industry, and Corporate Profits (Revised)', 'release_locator': '/news/2026/gross-domestic-product-3rd-quarter-2025-updated-estimate-gdp-industry-and-corporate'}, {'quarter': '2026-Q1', 'stage': 'Advance', 'year': 2026, 'wall_label': 'April 30 8:30 AM', 'utc_declared': '20260430T123000Z', 'uid': 'e2578bf1-6c88-477b-9400-c2d72f1e2ce8', 'title': 'GDP (Advance Estimate), 1st Quarter 2026', 'release_locator': '/news/2026/gdp-advance-estimate-1st-quarter-2026'}, {'quarter': '2026-Q1', 'stage': 'Second', 'year': 2026, 'wall_label': 'May 28 8:30 AM', 'utc_declared': '20260528T123000Z', 'uid': '52923702-195a-46ef-ab53-9dca9cb77ae7', 'title': 'GDP (Second Estimate) and Corporate Profits, 1st Quarter 2026', 'release_locator': '/news/2026/gdp-second-estimate-and-corporate-profits-1st-quarter-2026'}, {'quarter': '2026-Q1', 'stage': 'Third', 'year': 2026, 'wall_label': 'June 25 8:30 AM', 'utc_declared': '20260625T123000Z', 'uid': '2c05eec8-f749-4832-bd96-d171e37b5c17', 'title': 'GDP (Third Estimate), Industries, Corporate Profits, State GDP, and State Personal Income, 1st Quarter 2026', 'release_locator': '/news/2026/gdp-third-estimate-industries-corporate-profits-state-gdp-and-state-personal-income-1st'}, {'quarter': '2026-Q2', 'stage': 'Advance', 'year': 2026, 'wall_label': 'July 30 8:30 AM', 'utc_declared': '20260730T123000Z', 'uid': '2989d2ad-202c-48c8-ab87-51eafc234f96', 'title': 'GDP (Advance Estimate), 2nd Quarter 2026', 'release_locator': '/news/2026/gdp-advance-estimate-2nd-quarter-2026'}, {'quarter': '2026-Q2', 'stage': 'Second', 'year': 2026, 'wall_label': 'August 26 8:30 AM', 'utc_declared': '20260826T123000Z', 'uid': '84d38d69-e462-4dc2-8f9b-636779fcced5', 'title': 'GDP (Second Estimate) and Corporate Profits, 2nd Quarter 2026', 'release_locator': '/news/2026/gdp-second-estimate-and-corporate-profits-2nd-quarter-2026'}, {'quarter': '2026-Q2', 'stage': 'Third', 'year': 2026, 'wall_label': 'September 30 8:30 AM', 'utc_declared': '20260930T123000Z', 'uid': '1e85b6fb-a00d-4e0e-85dc-b2bde99e580f', 'title': 'GDP (Third Estimate), Industries, Corporate Profits, State GDP, and State Personal Income, 2nd Quarter 2026; State PCE, 2025', 'release_locator': '/news/2026/gdp-third-estimate-industries-corporate-profits-state-gdp-and-state-personal-income-2nd'}]

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def text_value(raw):
    out=[];i=0
    while i<len(raw):
        c=raw[i]
        if c=='\\':
            i+=1;require(i<len(raw) and raw[i] in '\\,;nN','unsupported ICS escape')
            c='\n' if raw[i] in 'nN' else raw[i]
        out.append(c);i+=1
    return ''.join(out)

def calendar(raw):
    require(len(raw)<=8*1024*1024,'ICS size')
    try:s=raw.decode('utf-8')
    except UnicodeError as e:raise ValueError('ICS encoding') from e
    require('\x00' not in s and '\n' not in s.replace('\r\n','') and '\r' not in s.replace('\r\n',''),'ICS requires CRLF')
    physical=s.split('\r\n');lines=[]
    for line in physical:
        if line.startswith((' ','\t')):
            require(bool(lines) and lines[-1] != '', 'orphan fold');lines[-1]+=line[1:]
        else:lines.append(line)
    if lines[-1]=='':lines.pop()
    require(lines[0]=='BEGIN:VCALENDAR' and lines[-1]=='END:VCALENDAR','calendar enclosure')
    header={};events=[];event=None;uids=set()
    for line in lines[1:-1]:
        require(bool(line),'empty logical line')
        if line=='BEGIN:VEVENT':
            require(event is None,'nested event');event={};continue
        if line=='END:VEVENT':
            require(event is not None,'unpaired event end')
            require(set(event)=={'SUMMARY','DTSTART','DURATION','DTSTAMP','UID','SEQUENCE','DESCRIPTION'},'event fields')
            require(event['UID'] not in uids,'duplicate UID');uids.add(event['UID'])
            require(re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',event['UID']) is not None,'UID encoding')
            require(re.fullmatch(r'0|[1-9][0-9]*',event['SEQUENCE']) is not None,'sequence encoding')
            require(event['DURATION']=='PT30M' and event['DESCRIPTION']=='www.bea.gov','unsupported event profile')
            for k in ['DTSTART','DTSTAMP']:
                require(re.fullmatch(r'[0-9]{8}T[0-9]{6}Z',event[k]) is not None,'UTC declaration syntax')
                try:datetime.strptime(event[k],'%Y%m%dT%H%M%SZ')
                except ValueError as e:raise ValueError('invalid calendar datetime') from e
            event['SUMMARY']=text_value(event['SUMMARY']);events.append(event);event=None;continue
        key,sep,value=line.partition(':');require(bool(sep),'property separator')
        name,semi,param=key.partition(';')
        require(name not in {'BEGIN','END'},'unsupported component')
        require(not semi or (name in {'DTSTART','DTSTAMP'} and param=='VALUE=DATE-TIME'),'unsupported parameters')
        dest=header if event is None else event
        require(name not in dest,'duplicate property')
        if event is None:require(not events,'late calendar metadata')
        dest[name]=value
    require(event is None,'unclosed event')
    require(header=={'VERSION':'2.0','PRODID':'//BEA-Release-Calendar-Subscription//','NAME':'BEA-Release-Calendar-Subscription','X-WR-CALNAME':'BEA-Release-Calendar-Subscription','TZID':'America/New_York','X-WR-TIMEZONE':'America/New_York'},'unsupported calendar header')
    return events

class Annual(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.active=False;self.count=0;self.rows=[];self.row=None;self.cell=None;self.h1=None;self.headings=[];self.ancestors=[]
    def handle_starttag(self,tag,attrs):
        if tag=='h1':self.h1=''
        if self.active or tag=='table':require(len({k for k,v in attrs})==len(attrs),'duplicate HTML attribute')
        a=dict(attrs)
        unsafe=(tag in {'script','style','template','iframe'} or a.get('aria-hidden')=='true' or 'hidden' in a or 'hidden' in a.get('class','').split() or 'display:none' in a.get('style','').replace(' ','').lower() or len({k for k,v in attrs})!=len(attrs))
        inherited_unsafe=any(x[1] for x in self.ancestors)
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.ancestors.append((tag,unsafe))
        if tag=='table':
            require(not self.active,'nested annual table')
            if a.get('id')=='release-schedule-table':
                require(not inherited_unsafe and not unsafe,'hidden/unsupported annual ancestor');self.active=True;self.count+=1
        if not self.active:return
        require(tag not in {'script','style','template','iframe'},'active/hidden table content')
        require(a.get('aria-hidden')!='true' and 'hidden' not in a and 'hidden' not in a.get('class','').split() and 'display:none' not in a.get('style','').replace(' ','').lower(),'hidden table content')
        if tag=='tr':require(self.row is None,'nested row');self.row=[]
        if tag in {'th','td'}:
            require(self.row is not None and self.cell is None,'cell structure');self.cell={'kind':tag,'text':'','attrs':a,'links':[]}
        if tag=='a' and self.cell is not None:self.cell['links'].append(a.get('href'))
    def handle_data(self,data):
        if self.h1 is not None:self.h1+=data
        if self.active and self.cell is not None:self.cell['text']+=data
    def handle_endtag(self,tag):
        for i in range(len(self.ancestors)-1,-1,-1):
            if self.ancestors[i][0]==tag:
                del self.ancestors[i:];break
        if tag=='h1' and self.h1 is not None:self.headings.append(' '.join(self.h1.split()));self.h1=None
        if not self.active:return
        if tag in {'th','td'}:
            require(self.cell is not None and self.cell['kind']==tag,'cell end');self.cell['text']=' '.join(self.cell['text'].split());self.row.append(self.cell);self.cell=None
        if tag=='tr':require(self.row is not None and self.cell is None,'row end');self.rows.append(self.row);self.row=None
        if tag=='table':require(self.row is None and self.cell is None,'table end');self.active=False

def annual(raw,year):
    require(len(raw)<=8*1024*1024,'annual size')
    h=Annual()
    try:h.feed(raw.decode('utf-8'));h.close()
    except UnicodeError as e:raise ValueError('annual encoding') from e
    require(h.count==1 and not h.active and h.headings==['Release Schedule'],'annual table/page identity')
    require(h.rows and [c['text'] for c in h.rows[0]]==[f'Year {year}','','Release',''] and all(c['kind']=='th' for c in h.rows[0]),'annual year/header')
    return h.rows[1:]

def consume(ics_raw, annual_2025_raw, annual_2026_raw, *, sha256):
    raws=[ics_raw,annual_2025_raw,annual_2026_raw]
    require(isinstance(sha256,(list,tuple)) and len(sha256)==3,'three source identities required')
    for raw,pin in zip(raws,sha256):
        require(isinstance(raw,bytes) and isinstance(pin,str) and re.fullmatch(r'[0-9a-f]{64}',pin) is not None,'bytes/hash types')
        require(hashlib.sha256(raw).hexdigest()==pin,'raw identity mismatch')
    events=calendar(ics_raw);rows={2025:annual(annual_2025_raw,2025),2026:annual(annual_2026_raw,2026)};out=[]
    for sel in SELECTION:
        matched=[e for e in events if e['SUMMARY']==sel['title']]
        require(len(matched)==1,'selected event missing/duplicate');e=matched[0]
        require(e['UID']==sel['uid'] and e['DTSTART']==sel['utc_declared'],'selected UID/UTC substitution')
        matched_rows=[r for r in rows[sel['year']] if any(c['text']==sel['title'] for c in r)]
        require(len(matched_rows)==1,'selected annual row missing/duplicate');r=matched_rows[0]
        require(len(r)==4 and r[2]['text']==sel['title'],'selected annual row columns')
        require(all(c['kind']=='td' and c['attrs'].get('colspan','1')=='1' and c['attrs'].get('rowspan','1')=='1' for c in r),'selected cell shape/span')
        require(r[0]['attrs'].get('headers')=='view-field-scheduled-release-date-1-table-column' and r[2]['attrs'].get('headers')=='view-field-scheduled-release-subject-table-column','selected column identity')
        require(r[0]['text']==sel['wall_label'] and r[1]['text']=='News' and r[3]['text']=='View' and r[3]['links']==[sel['release_locator']],'selected annual date/kind/locator')
        out.append(dict(sel,dtstamp_declared=e['DTSTAMP'],sequence_declared=e['SEQUENCE'],authenticated_available_at='NOT_ESTABLISHED'))
    return {'status':'FINITE_CALENDAR_DECLARATIONS_BOUND','events':out,'source_sha256':list(sha256),'global_timezone_declared':'America/New_York','time_comparison':'LITERAL_SOURCE_DECLARATIONS_NO_TZDB_CONVERSION','mandatory_universe':'NOT_ESTABLISHED','historical_version_chain':'NOT_ESTABLISHED','first_bytes':'NOT_ESTABLISHED','exact_parser_tzdb':'NOT_ESTABLISHED','real_admission':'NOT_READY','real_genesis_readiness':'NOT_ESTABLISHED','prospective_eligible':False,'protocol_state_change':'NONE'}
