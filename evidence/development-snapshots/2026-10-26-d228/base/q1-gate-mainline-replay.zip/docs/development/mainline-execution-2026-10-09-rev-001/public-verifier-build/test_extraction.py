"""Safety boundaries for the fixed public-source extraction (no key generation)."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).parent
spec = importlib.util.find_spec('extract_sources')
if spec:
    import extract_sources as extraction
else:
    extraction = None


class ExtractionTests(unittest.TestCase):
    def require(self):
        self.assertIsNotNone(extraction, 'fixed-source extractor not implemented')
        return extraction

    def test_source_mutation_refused(self):
        module = self.require()
        name = 'include/sodium/private/common.h'
        original = (module.SOURCE_ROOT / name).read_bytes()
        with self.assertRaises(ValueError):
            module.validate_source(name, original + b'\n/* public mutation */\n')
        with self.assertRaises(ValueError):
            module.validate_source('randombytes/randombytes.c', b'')

    def test_unknown_destination_preserved(self):
        module = self.require()
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            target = Path(tmp) / 'output'
            target.mkdir()
            sentinel = target / 'unknown.txt'
            sentinel.write_text('preserve')
            with self.assertRaises(FileExistsError):
                module.prepare(target)
            self.assertEqual(sentinel.read_text(), 'preserve')

    def test_exact_helpers_and_provenance(self):
        module = self.require()
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            target = Path(tmp) / 'generated'
            manifest = module.prepare(target)
            self.assertEqual(len(manifest['source_pins']), 23)
            self.assertEqual(len(manifest['fragments']), 6)
            for fragment in manifest['fragments']:
                source = (module.SOURCE_ROOT / fragment['source']).read_bytes()
                lines = source.splitlines(keepends=True)
                segment = b''.join(lines[fragment['first_line'] - 1:fragment['last_line']])
                self.assertEqual(hashlib.sha256(segment).hexdigest(), fragment['segment_sha256'])
                self.assertIn(segment, (target / fragment['output']).read_bytes())
            combined = '\n'.join((target / name).read_text() for name in
                                  ['point_guard.c', 'hinit.c', 'detached.c', 'public_utils.c'])
            for forbidden in ['randombytes', 'crypto_sign_ed25519_open(',
                              'crypto_sign_ed25519_detached(', '_sodium_alloc_init',
                              'sodium_init(', 'keypair(', '"core.h"']:
                self.assertNotIn(forbidden, combined)
            self.assertIn('ge25519_is_on_main_subgroup', combined)
            self.assertIn('crypto_sign_ed25519_verify_detached', combined)
            for item in manifest['generated_files']:
                self.assertEqual(hashlib.sha256((target / item['path']).read_bytes()).hexdigest(),
                                 item['raw_sha256'])

    def test_configuration_excludes_compat_and_entropy_paths(self):
        module = self.require()
        config = module.CONFIG
        for macro in ['ED25519_COMPAT', 'ED25519_NONDETERMINISTIC',
                      'HAVE_WEAK_SYMBOLS', 'CONFIGURED']:
            self.assertIn('defined(' + macro + ')', config)
        self.assertIn('#define HAVE_TI_MODE 1', config)
        self.assertIn('#define HAVE_GCC_MEMORY_FENCES 1', config)
        self.assertNotIn('#define CONFIGURED', config)


if __name__ == '__main__':
    unittest.main()
