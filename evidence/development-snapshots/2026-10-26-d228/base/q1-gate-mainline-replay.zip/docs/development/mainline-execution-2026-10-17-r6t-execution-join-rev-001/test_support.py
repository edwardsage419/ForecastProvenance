"""Keyless synthetic-only unit records, never actual reports or protocol facts."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import ModuleType

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
I = json.loads((HERE / 'INPUTS.json').read_text())
PINS = {x['path']: x['sha256'] for x in I['sources']}


def load(relative, name):
    path = ROOT / relative
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PINS[relative]:
        raise RuntimeError('Fixed unit dependency changed')
    module = ModuleType(name); module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


T = load('docs/development/mainline-execution-2026-10-17-r4t-contract-join-rev-001/test_support.py', '_r6t_case')
R = load('docs/development/mainline-execution-2026-10-09-rev-001/full-report-consumption/report_consumer.py', '_r6t_report')
H = T.T


def summarize(args, ids=('CHECK-A', 'CHECK-B'), statuses=None, kind='TRUST_CORE_TEST_REPORT'):
    """Rebuild only synthetic summary controls after deliberate unit changes."""
    registry = json.loads(args[4])['registry']['ref']
    catalog = {'format': 'FP_DEV_R6_CHECK_CATALOG_V1', 'scope': 'FINITE_DEVELOPMENT_SCOPE_ONLY',
               'report_kind': kind, 'subject_ref': H.external('UNIT-SUBJECT'),
               'validator_contract_ref': deepcopy(args[2]['refs']['vc']),
               'content_profile_ref': H.external('UNIT-CONTENT'),
               'checks': [{'check_id': cid, 'required_support_refs': [H.external('UNIT-SUPPORT-' + cid)],
                           'required_coverage': [{'dimension': 'OPERATION', 'member_ref': deepcopy(registry)}]}
                          for cid in ids]}
    raw = H.raw(catalog); digest = H.digest(raw)
    observations = [{'check_id': c['check_id'], 'status': (statuses or {}).get(c['check_id'], 'PASS'),
                     'reason_code': 'SYNTHETIC_TEST_ONLY', 'support_refs': deepcopy(c['required_support_refs']),
                     'coverage': deepcopy(c['required_coverage']), 'blocking_finding_refs': []}
                    for c in catalog['checks']]
    checks = R._C.build_checks(raw, digest, observations)
    deps = [catalog['content_profile_ref'], registry] + [c['required_support_refs'][0] for c in catalog['checks']]
    deps = sorted(deepcopy(deps), key=lambda r: (r['object_id'], r['content_sha256']))
    states = [x['status'] for x in observations]
    result = 'INVALID' if 'FAIL' in states else 'INELIGIBLE_TRUST_UNKNOWN' if 'UNKNOWN' in states else 'VALID'
    body = {'schema_version': '2.0', 'validator_contract_ref': catalog['validator_contract_ref'],
            'trusted_manifest_ref': catalog['subject_ref'], 'candidate_object_ref': catalog['subject_ref'],
            'dependency_refs': deps, 'result': result, 'checks': checks, 'derived_claims': []}
    report = H.seal(body, 'ValidationReport', 'SYNTHETIC-R6T')
    args[1] = H.raw(report)
    args[0] = {'format': 'FP_DEV_R6_REPORT_EXPECTED_V1', 'scope': 'FINITE_DEVELOPMENT_SCOPE_ONLY',
               'report_ref': H.ref(report), 'report_raw_sha256': H.digest(args[1]),
               'subject_ref': deepcopy(catalog['subject_ref']), 'validator_contract_ref': deepcopy(catalog['validator_contract_ref']),
               'report_kind': kind, 'content_profile_ref': deepcopy(catalog['content_profile_ref']), 'dependency_refs': deps}
    args[8:10] = [raw, digest]


def case():
    base, body = T.case()
    args = [None, None, *base[:6], None, None, *base[6:]]
    summarize(args)
    return args, body


def rebind(args, body):
    base = args[2:8] + args[10:14]
    T.rebind_report(base, body)
    args[11] = base[7]
    summarize(args)


def shrink_all_supplied_scope(args, body):
    """Shrink every synthetic supplied layer; no independent universe supplied."""
    expected, records = args[2:4]
    objects = {k: json.loads(records[k]) for k in ('tc1', 'tc2', 'ib', 'vc')}
    def reseal(obj, kind, label):
        payload = {k: deepcopy(v) for k, v in obj.items()
                   if k not in ('object_type', 'object_id', 'payload_sha256', 'content_sha256')}
        return H.seal(payload, kind, label)
    registry = json.loads(args[6]); registry['operations'] = registry['operations'][:1]
    registry = reseal(registry, 'OperationRegistry', 'UNIT-REDUCED-REGISTRY')
    mapping = json.loads(args[4]); mapping['operations'] = mapping['operations'][:1]
    mapping['components'] = mapping['components'][:1]; mapping['registry']['ref'] = H.ref(registry)
    args[4] = H.raw(mapping); args[5] = H.digest(args[4]); args[6] = H.raw(registry)
    del args[7]['ROLE-B']
    tc = objects['tc1']; tc['command_declarations'] = tc['command_declarations'][:1]
    tc['operation_coverage'] = tc['operation_coverage'][:1]
    tc = reseal(tc, 'TestContract', 'UNIT-REDUCED-TC1'); records['tc1'] = H.raw(tc)
    expected['refs']['tc1'] = H.ref(tc); expected['tc1_raw_sha256'] = H.digest(records['tc1'])
    for key in ('fixture_refs', 'command_declarations', 'runtime_profile_ref', 'operation_coverage',
                'expected_result_vocabulary', 'projection_profile_ref'):
        objects['tc2'][key] = deepcopy(tc[key])
    objects['tc2']['execution_binding']['test_definition_ref'] = H.ref(tc)
    objects['ib']['entrypoint_bindings'] = objects['ib']['entrypoint_bindings'][:1]
    refs = [H.ref(json.loads(args[7]['ROLE-A']))]
    objects['vc']['component_contract_refs'] = deepcopy(refs)
    objects['vc']['operation_registry_ref'] = H.ref(registry)
    # Temporary changed unit objects are resealed by the existing post-graph helper below.
    for slot in ('tc2', 'ib', 'vc'): records[slot] = H.raw(objects[slot])
    args[10]['invocations'] = args[10]['invocations'][:1]
    args[10]['bindings'].update(test_definition_ref=H.ref(tc), component_contract_refs=deepcopy(refs))
    args[10]['test_definition_raw_sha256'] = H.digest(records['tc1'])
    body.update(test_definition_ref=H.ref(tc), test_definition_raw_sha256=H.digest(records['tc1']), component_contract_refs=deepcopy(refs))
    body['invocations'] = body['invocations'][:1]; body['results'] = body['results'][:1]
    rebind(args, body); summarize(args, ids=('CHECK-A',))
