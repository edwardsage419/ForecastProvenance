"""Reuse existing keyless fixtures; no actual TC/report or protocol facts."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import ModuleType
from forecast_trust_core import r4t_execution_content_v1 as C

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
B = HERE.parent / 'mainline-execution-2026-10-09-rev-001'
I = json.loads((HERE / 'INPUTS.json').read_text())
PINS = {x['path']: x['sha256'] for x in I['sources']}
assert hashlib.sha256(Path(C.__file__).read_bytes()).hexdigest() == I['installed_product_module']['sha256']


def load_fixed(path, name):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PINS[str(path.relative_to(ROOT))]
    mod = ModuleType(name); mod.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), mod.__dict__)
    return mod


T = load_fixed(B / 'operation-mapping/test_support.py', '_join_old_fixtures')
source = ROOT / 'tests/test_r4t_execution_content_v1.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == PINS[str(source.relative_to(ROOT))]
nodes = [n for n in ast.parse(source.read_bytes()).body
         if isinstance(n, ast.FunctionDef) and n.name in ('ref', 'fixture')]
assert [n.name for n in nodes] == ['ref', 'fixture']
F = ModuleType('_join_r4t_fixture')
F.__dict__.update(deepcopy=deepcopy, hashlib=hashlib)
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<fixed-synthetic-fixture-functions>', 'exec'), F.__dict__)
SCHEMA = (B / 'r4t-record-format-and-inventory-2026-10-16-rev-001/development_test_run_report_v1.candidate.schema.json').read_bytes()
digest = T.digest
ref = T.ref


def rebind_report(args, body):
    """Repin only synthetic post-run graph after an intentional test mutation."""
    expected, records = args[:2]
    report = T.seal(body, 'DevelopmentTestRunReport', 'JOIN-REPORT')
    records['r4t'] = T.raw(report) + b'\n'
    def put(slot, kind, obj):
        payload = {k: deepcopy(v) for k, v in obj.items()
                   if k not in ('object_type', 'object_id', 'payload_sha256', 'content_sha256')}
        obj = T.seal(payload, kind, 'JOIN-' + slot)
        records[slot] = T.raw(obj) + b'\n'
        expected['refs'][slot] = ref(obj)
        return obj
    tc2 = json.loads(records['tc2'])
    tc2['execution_binding']['test_report_ref'] = ref(report)
    tc2['execution_binding']['test_report_raw_sha256'] = digest(records['r4t'])
    tc2 = put('tc2', 'TestContract', tc2)
    ib = json.loads(records['ib'])
    ib['legacy_validator_binding']['test_report']['sha256'] = digest(records['r4t'])
    ib = put('ib', 'ImplementationBinding', ib)
    expected['legacy_validator_binding'] = deepcopy(ib['legacy_validator_binding'])
    vc = json.loads(records['vc']); vc['implementation_binding_ref'] = ref(ib); vc['test_contract_ref'] = ref(tc2)
    put('vc', 'ValidatorContract', vc)
    expected['refs']['r4t'] = ref(report)
    args[7] = {'report_ref': ref(report), 'report_raw_sha256': digest(records['r4t'])}


def case():
    args = T.case()
    tc1 = json.loads(args[1]['tc1']); runtime = json.loads(args[1]['runtime'])
    ib = json.loads(args[1]['ib']); vc = json.loads(args[1]['vc'])
    body, old_expected, artifacts = F.fixture()
    bindings = deepcopy(old_expected['bindings'])
    bindings.update(test_definition_ref=ref(tc1), runtime_profile_ref=ref(runtime),
                    source_file_manifest_ref=ib['source_file_manifest_ref'], package_artifact_ref=ib['package_artifact_ref'],
                    dependency_lock_ref=ib['dependency_lock_ref'], component_contract_refs=vc['component_contract_refs'])
    body.update(bindings); body['test_definition_raw_sha256'] = digest(args[1]['tc1'])
    template = body['invocations'][0]; row = body['results'][0]
    body['invocations'] = []; body['results'] = []; invocations = []
    for n, suffix in enumerate(('A', 'B')):
        command = tc1['command_declarations'][n]
        inv = deepcopy(template)
        inv.update(invocation_id='INV.' + suffix, ordinal=n, command_id=command['command_id'],
                   argv=command['argv'], executable_sha256=runtime['execution_engine']['executable_sha256'])
        result = deepcopy(row)
        result.update(instance_id='CASE.' + suffix, invocation_id=inv['invocation_id'], check_id='CHECK-' + suffix,
                      operation_id='OP-' + suffix, fixture_refs=deepcopy(tc1['fixture_refs']))
        body['invocations'].append(inv); body['results'].append(result)
        expected_inv = {k: deepcopy(inv[k]) for k in C.INV_FIELDS}
        instance = {k: deepcopy(result[k]) for k in C.INSTANCE_FIELDS}
        instance['allowed_outcomes'] = ['SUCCESS']
        expected_inv.update(expected_exit_codes=[0], instances=[instance])
        invocations.append(expected_inv)
    pre = {'format': 'FP_DEV_R4T_PRE_RUN_EXPECTATIONS_V1', 'scope': 'FINITE_DEVELOPMENT_SCOPE_ONLY',
           'schema_raw_sha256': C.SCHEMA_SHA256, 'bindings': bindings,
           'test_definition_raw_sha256': digest(args[1]['tc1']), 'run_id': body['run_id'], 'invocations': invocations}
    args.extend([pre, None, SCHEMA, artifacts])
    rebind_report(args, body)
    return args, body
