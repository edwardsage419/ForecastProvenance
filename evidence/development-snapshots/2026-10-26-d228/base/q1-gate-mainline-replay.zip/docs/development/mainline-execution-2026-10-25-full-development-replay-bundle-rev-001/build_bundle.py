"""Task-owned, exact finite development transport. No verifier or protocol action."""
import ast
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import stat
from types import ModuleType
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MAX_BYTES = 64*1024*1024
TRACE = 'docs/development/mainline-execution-2026-10-18-observed-development-run-rev-001'
OLD = 'docs/development/mainline-execution-2026-10-19-relocated-finite-replay-rev-001/BUNDLE_INPUTS.json'
SCRIPTS = 'scripts/development/offline_evidence/'
README = '''# Finite 14-module development replay

This package transports the existing development CLI and exact finite public
inputs. Run with an already compatible Python environment:

    /absolute/path/to/existing/python -I -B scripts/development/offline_evidence/cli.py mainline --json

Expected: 14 modules; seven finite sample modules OBSERVED, seven real-evidence
modules MISSING; exit1, UNRESOLVED, NOT_READY, protocol_state_change NONE. CPI
includes the FRASER archive PDF; the public Core observation remains a retained
sample, not project Strong or current RPC. Four domain reports remain synthetic.

Python/dependencies are NOT included or installed. Tested with existing repository
Python3.12.3 and jsonschema4.26.0; GDP XLSX parsing uses stdlib. PDF workers use
the existing bundled Python path selected by cli.py (Python3.12.14/pypdf6.10.0).
The repository runtime has no pypdf/openpyxl; the bundled runtime has no jsonschema.
Openpyxl3.1.5 is present in the bundle runtime but not required by the XLSX consumer.
Other hosts need compatible
existing environments; missing runtime/dependencies remain UNAVAILABLE. No
cross-platform or full runtime/build closure is claimed. Do not run a node,
supervisor, retained command, or historical absolute path from these materials.

Native diagnostic product sources come from the exact retained D176 public wheel.
The selected21 source admission/compiled-code checks are unchanged; the remaining
native diagnostic sources are not promoted into that21-module admission scope.
Source code filenames/compiled hashes vary with extraction root, so exact compiled
fingerprints must be retained separately rather than treated as portable hashes.

DEVELOPMENT_BUNDLE_MANIFEST.json fixes raw transport identities only, not a complete
independently required protocol universe, signing authority, or software trust.
The inventory does not include itself. Check the archive against a separately
retained outer digest and check listed raw member identities before execution;
this package does not authenticate a substituted launcher or inventory. Extract
only regular, safe relative members into a new directory, never over other work.

No private key, real signing message, real acceptance/freeze/qualification/Genesis,
runtime environment, wallet or chain data is supplied. The seven real-evidence
gaps require independent project facts; this development package does not fill them.
'''


def declarations(raw):
    result = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                if (isinstance(node.value, ast.BinOp) and isinstance(node.value.op, ast.Div)
                        and isinstance(node.value.left, ast.Name) and node.value.left.id == 'ROOT'
                        and isinstance(node.value.right, ast.Constant)
                        and type(node.value.right.value) is str):
                    result[node.targets[0].id] = node.value.right.value
    return result


def safe_path(name):
    if type(name) is not str or len(name) > 512 or '\\' in name:
        raise ValueError('unsafe transport path')
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or '..' in path.parts or str(path) != name:
        raise ValueError('unsafe transport path')
    return path


def bootstrap_reader(root, anchor):
    """Only bootstrap the fixed passive reader, then reuse its safe exact reads."""
    target = root
    if target.is_symlink() or not target.is_dir():
        raise ValueError('unsafe root')
    for part in safe_path(anchor['path']).parts:
        target = target/part
        if target.is_symlink():
            raise ValueError('unsafe reader path')
    if not stat.S_ISREG(target.stat().st_mode) or target.stat().st_size != anchor['bytes']:
        raise ValueError('reader identity differs')
    raw = target.read_bytes()
    if len(raw) != anchor['bytes'] or sha256(raw).hexdigest() != anchor['sha256']:
        raise ValueError('reader identity differs')
    reader = ModuleType('d204_fixed_passive_reader')
    reader.__file__ = str(target)
    # Reuse only the pinned reader definitions and imports. Running the worker
    # module body would read its catalog before that catalog was admitted.
    body = [node for node in ast.parse(raw).body
            if isinstance(node, (ast.Import, ast.ImportFrom))
            or isinstance(node, (ast.ClassDef, ast.FunctionDef))
            and node.name in {'OfflineFailure', 'read_fixed'}]
    exec(compile(ast.Module(body=body, type_ignores=[]), str(target), 'exec'), reader.__dict__)
    return reader


def build_bundle(output, root=ROOT, max_bytes=MAX_BYTES):
    """Build only the anchored developer-supplied finite closure; never scan root."""
    output, root = Path(output), Path(root).absolute()
    if output.exists() or output.is_symlink():
        raise FileExistsError(output)
    if type(max_bytes) is not int or not 0 < max_bytes <= MAX_BYTES:
        raise ValueError('bounded positive byte budget required')
    anchors = json.loads((HERE/'ANCHORS.json').read_text())
    worker = next(r for r in anchors if r['path'] == SCRIPTS+'worker.py')
    reader = bootstrap_reader(root, worker)
    files, origins = {}, {}
    def put(name, raw, origin):
        safe_path(name)
        if name in files:
            if files[name] != raw:
                raise ValueError('conflicting transport identities: '+name)
            return
        if len(files) >= 2048 or sum(map(len, files.values()))+len(raw) > max_bytes:
            raise ValueError('finite transport budget exceeded')
        files[name], origins[name] = raw, origin
    def read(record):
        name = record['path']; safe_path(name)
        if name in files:
            raw = files[name]
            if len(raw) != record['bytes'] or sha256(raw).hexdigest() != record['sha256']:
                raise ValueError('conflicting raw identity: '+name)
            return raw
        if type(record['bytes']) is not int or not 0 <= record['bytes'] <= max_bytes:
            raise ValueError('bounded file size required')
        raw = reader.read_fixed(root, name, record)
        put(name, raw, {'kind':'FIXED_REPOSITORY_PUBLIC_FILE'})
        return raw
    for row in anchors:
        read(row)
    # Reuse the previous safe finite inventory, updating only anchored script
    # versions; old package remains untouched and is not silently re-pinned.
    for row in json.loads(files[OLD]):
        if row['path'] not in files:
            read(row)
    catalog = json.loads(files[SCRIPTS+'catalog.json'])
    for case in catalog.values():
        for row in case['sources']+case['inputs']:
            read(row)
    main = declarations(files[SCRIPTS+'mainline_worker.py'])
    for group, directory in (('TRACE_FILES','TRACE_DIRECTORY'),('PROOF_FILES','PROOF_DIRECTORY'),
                             ('HEADER_FILES','HEADER_DIRECTORY'),('CHAIN_FILES','CHAIN_DIRECTORY'),
                             ('CORE_FILES','CORE_DIRECTORY'),('PROVENANCE_FILES','TRACE_DIRECTORY')):
        for name, size, digest in main[group].values():
            read({'path':main[directory]+'/'+name,'bytes':size,'sha256':digest})
    declared = json.loads(files[TRACE+'/INPUTS_ATTEMPT2.json'])
    source_rows = {r['path']:r for r in declared['sources']}
    loaded = json.loads(files[TRACE+'/raw-attempt2/loaded-code.json'])
    for row in loaded['executed_sources']:
        if row['kind'] == 'PREDECLARED_REPOSITORY_SOURCE':
            source = source_rows[row['path']]
            if source['sha256'] != row['sha256']:
                raise ValueError('executed source declaration differs')
            read(source)
    lock = json.loads(files[TRACE+'/pre-attempt2/material-lock.json'])
    for row in lock['wheels']:
        read(row)
    package = json.loads(files[TRACE+'/pre-attempt2/material-package.json'])
    product = next(r for r in lock['wheels'] if r['sha256'] == package['raw_sha256'])
    if product['path'] != package['path']:
        raise ValueError('product artifact differs')
    # Extract public product Python members in memory. Do not copy any unknown
    # working product files, runtime absolute paths, environment or cached pyc.
    with ZipFile(BytesIO(files[product['path']])) as wheel:
        names = set()
        for member in wheel.infolist():
            name = member.filename
            if not name.startswith('forecast_trust_core/') or not name.endswith('.py'):
                continue
            safe_path(name)
            if name in names or member.file_size > 2_000_000:
                raise ValueError('ambiguous or oversized wheel member')
            names.add(name)
            mode = member.external_attr >> 16
            if stat.S_IFMT(mode) not in (0, stat.S_IFREG):
                raise ValueError('nonregular wheel source')
            put('src/'+name, wheel.read(member), {'kind':'FIXED_PUBLIC_WHEEL_MEMBER',
                'wheel':product['path'],'wheel_sha256':product['sha256'],'member':name})
    put('README.md', README.encode(), {'kind':'DEVELOPMENT_SCOPE_DOCUMENT'})
    inventory = {'artifact_role':'DEVELOPMENT_TRANSFER_INVENTORY_NOT_PROTOCOL_TRUST',
        'coverage':'EXACT_FINITE_14_MODULE_DEVELOPMENT_INPUTS_NOT_REAL_REQUIRED_UNIVERSE',
        'real_admission':'NOT_READY','protocol_state_change':'NONE',
        'complete_runtime_closure':'NOT_ESTABLISHED',
        'files':[{'path':name,'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'origin':origins[name]}
                 for name,raw in sorted(files.items())]}
    manifest = (json.dumps(inventory,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    if sum(map(len,files.values()))+len(manifest) > max_bytes:
        raise ValueError('finite transport budget exceeded')
    files['DEVELOPMENT_BUNDLE_MANIFEST.json'] = manifest
    created = False
    try:
        with output.open('xb') as stream:
            created = True
            with ZipFile(stream,'w',compression=ZIP_DEFLATED,compresslevel=6) as archive:
                for name, raw in sorted(files.items()):
                    info = ZipInfo(name, date_time=(1980,1,1,0,0,0))
                    info.create_system = 3
                    info.external_attr = 0o100644 << 16
                    info.compress_type = ZIP_DEFLATED
                    archive.writestr(info,raw,compress_type=ZIP_DEFLATED,compresslevel=6)
    except BaseException:
        if created:
            output.unlink(missing_ok=True)  # Only this invocation's new artifact.
        raise
    return inventory


if __name__ == '__main__':
    destination = HERE/'full-development-replay.zip'
    result = build_bundle(destination)
    print(json.dumps({'path':str(destination),'files':len(result['files']),
                      'archive_bytes':destination.stat().st_size,'real_admission':'NOT_READY'}))
