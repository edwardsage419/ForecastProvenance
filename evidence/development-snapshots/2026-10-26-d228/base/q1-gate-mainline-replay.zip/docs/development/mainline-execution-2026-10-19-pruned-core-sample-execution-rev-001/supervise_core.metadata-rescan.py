"""Task-owned foreground controller; no private-key or cookie-content access."""
import datetime
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/sage/Library/Application Support/ForecastProvenance/CoreResearch-Pruned-31.1')
PKG = Path(__file__).resolve().parent
DATA = ROOT / 'data'
CONF = DATA / 'bitcoin.conf'
BIN = ROOT / 'software' / 'bitcoin-31.1' / 'bin'
HASH = '000000000000000000007f0753c6209263c7072e51b725e89e75a0c708b90345'
ALLOWED = {'getblockchaininfo', 'getblockhash', 'getblockheader', 'getnetworkinfo', 'getpeerinfo', 'stop'}
BUDGET = 30 * 2**30
# Stop early enough for normal shutdown writes. Neither line is an atomic quota.
DIRECTORY_STOP = BUDGET - 512 * 2**20
FREE_STOP = 30 * 2**30 + 512 * 2**20
FOOTPRINT_STOP = 2 * 2**30 - 64 * 2**20
RSS_STOP = 8 * 2**30 - 64 * 2**20
READ_COOLDOWN_TARGET_SECONDS = 120
NODE = None
STOP_REQUEST = False


class ObservationStop(Exception):
    """A fixed supervisor stop category, never arbitrary RPC text."""


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, obj):
    p = PKG / name
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(p)


def event(obj):
    obj = {'observed_at_utc': now(), **obj}
    with (PKG / 'PUBLIC_EVENTS.jsonl').open('a') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + '\n')
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def project_physical_footprint(summary):
    # Do not retain other labels, regions, paths, addresses or the original output.
    lines = [line.strip() for line in summary.splitlines()
             if line.lstrip().startswith('Physical footprint:')]
    if len(lines) != 1:
        return {'ok': False, 'error_kind': 'FOOTPRINT_MISSING_OR_DUPLICATE'}
    match = re.fullmatch(r'Physical footprint:[ \t]*([0-9]{1,7}(?:\.[0-9]{1,3})?)([KMGT]?)[ \t]*', lines[0])
    if not match:
        return {'ok': False, 'error_kind': 'FOOTPRINT_INVALID_DISPLAY'}
    number, unit = match.groups()
    decimals = len(number.split('.')[1]) if '.' in number else 0
    # Binary units and half a displayed unit of rounding, rounded up to bytes.
    scale = 1024 ** {'': 0, 'K': 1, 'M': 2, 'G': 3, 'T': 4}[unit]
    upper = ((Decimal(number) + Decimal(1).scaleb(-decimals) / 2) * scale)
    return {'ok': True, 'physical_footprint_display': number + unit,
            'physical_footprint_upper_bytes': int(upper.to_integral_value(rounding=ROUND_CEILING)),
            'source': 'VMMAP_SUMMARY', 'upper_bound_includes_display_rounding': True}


def measure_owned_memory():
    child = NODE
    if child is None or child.poll() is not None:
        return {'ok': False, 'error_kind': 'NO_LIVE_OWN_CHILD'}
    result = {'ok': False, 'pid': child.pid}
    try:
        ps = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(child.pid)],
                            capture_output=True, text=True, timeout=5)
        if ps.returncode or not re.fullmatch(r'[0-9]{1,12}', ps.stdout.strip()) or int(ps.stdout.strip()) <= 0:
            return {**result, 'error_kind': 'OWN_RSS_UNAVAILABLE'}
        result['rss_bytes'] = int(ps.stdout.strip()) * 1024
        if NODE is not child or child.poll() is not None:
            return {**result, 'error_kind': 'OWN_CHILD_CHANGED_OR_EXITED'}
        native = subprocess.run(['/usr/bin/vmmap', '-summary', str(child.pid)],
                                capture_output=True, text=True, timeout=5)
        if NODE is not child or child.poll() is not None:
            return {**result, 'error_kind': 'OWN_CHILD_CHANGED_OR_EXITED'}
        if native.returncode:
            return {**result, 'error_kind': 'VMMAP_COMMAND_FAILED'}
        return {**result, **project_physical_footprint(native.stdout)}
    except subprocess.TimeoutExpired:
        return {**result, 'error_kind': 'OWN_MEMORY_COMMAND_TIMEOUT'}
    except OSError:
        return {**result, 'error_kind': 'OWN_MEMORY_COMMAND_UNAVAILABLE'}


def resources():
    # Only metadata in this exact newly created root, no symlinks followed.
    def walk_error(error):
        raise error
    for restart in range(2):
        logical = allocated = 0
        try:
            for directory, dirs, files in os.walk(ROOT, followlinks=False, onerror=walk_error):
                for name in [*dirs, *files]:
                    s = (Path(directory) / name).lstat()
                    if __import__('stat').S_ISLNK(s.st_mode):
                        raise RuntimeError('unexpected symlink in new research root')
                    logical += s.st_size
                    allocated += s.st_blocks * 512
        except FileNotFoundError:
            if restart:
                raise
            continue  # Core may remove a log/pruned file after enumeration.
        break  # Retain only a complete pass, never partial or combined totals.
    free = shutil.disk_usage(ROOT).free
    memory = measure_owned_memory()
    return {'logical_bytes': logical, 'allocated_bytes': allocated,
            'metadata_walk_restarts': restart,
            'free_bytes': free, 'own_node_rss_bytes': memory.get('rss_bytes'),
            'own_node_memory': memory, 'load_average': os.getloadavg()}


def require_resource_bounds(resource):
    status = None
    memory = resource.get('own_node_memory', {})
    rss = resource.get('own_node_rss_bytes')
    footprint = memory.get('physical_footprint_upper_bytes')
    if max(resource['logical_bytes'], resource['allocated_bytes']) >= DIRECTORY_STOP:
        status = 'DIRECTORY_BUDGET_STOP'
    elif resource['free_bytes'] <= FREE_STOP:
        status = 'FREE_SPACE_RESERVE_STOP'
    elif (memory.get('ok') is not True or type(rss) is not int or rss <= 0
          or type(footprint) is not int or footprint <= 0):
        status = 'OWN_NODE_MEMORY_OBSERVATION_UNAVAILABLE'
    elif rss >= RSS_STOP:
        status = 'OWN_NODE_RSS_LIMIT_STOP'
    elif footprint >= FOOTPRINT_STOP:
        status = 'OWN_NODE_FOOTPRINT_LIMIT_STOP'
    if status:
        event({'stage': 'RESOURCE_STOP_OBSERVATION', 'status': status, 'resources': resource})
        raise ObservationStop(status)


def project_peer_diagnostics(peers):
    """Finite derived counters only; never return addresses or the original response."""
    assert type(peers) is list
    numbers = ('presynced_headers', 'synced_headers', 'synced_blocks',
               'bytesrecv', 'bytessent', 'lastrecv', 'lastsend')
    enums = {'connection_type': {'inbound', 'outbound-full-relay', 'block-relay-only',
                                  'manual', 'addr-fetch', 'feeler'},
             'transport_protocol_type': {'detecting', 'v1', 'v2'}}
    rows = []
    for index, peer in enumerate(peers, 1):
        row = {'row': index, 'missing_fields': [], 'invalid_fields': []}
        if type(peer) is not dict:
            rows.append({'row': index, 'invalid_row': True})
            continue
        selected = {name: peer.get(name) for name in numbers}
        for source, message, target in [('bytesrecv_per_msg', 'headers', 'bytesrecv_headers'),
                                        ('bytessent_per_msg', 'getheaders', 'bytessent_getheaders')]:
            value = peer.get(source)
            selected[target] = value.get(message) if type(value) is dict else None
        for name, value in selected.items():
            if value is None:
                row['missing_fields'].append(name)
            elif type(value) is int:
                row[name] = value
            else:
                row['invalid_fields'].append(name)
        for name, choices in enums.items():
            value = peer.get(name)
            if value is None:
                row['missing_fields'].append(name)
            elif type(value) is str and value in choices:
                row[name] = value
            else:
                row['invalid_fields'].append(name)
        rows.append(row)
    return {'derived_diagnostic_only': True, 'raw_response_retained': False, 'peers': rows}


def check_run_boundary(deadline):
    if STOP_REQUEST:
        raise ObservationStop('USER_OR_SIGNAL_STOP')
    if (PKG / 'STOP_REQUESTED').exists():
        raise ObservationStop('SUPERVISOR_STOP_REQUEST')
    if time.monotonic() >= deadline:
        raise ObservationStop('SEGMENT_60_MINUTE_BOUND')
    if NODE is None or NODE.poll() is not None:
        raise ObservationStop('NODE_EXITED')


def guarded_cli_run(command, deadline):
    """A finite second read; keep supervising while draining its stdout/stderr."""
    check_run_boundary(deadline)
    require_resource_bounds(resources())
    check_run_boundary(deadline)
    begun = time.monotonic()
    helper = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    next_resource_check = begun + 5
    try:
        while True:
            check_run_boundary(deadline)
            elapsed = time.monotonic() - begun
            if elapsed >= 37:
                raise subprocess.TimeoutExpired(command, 37)
            if time.monotonic() >= next_resource_check:
                require_resource_bounds(resources())
                check_run_boundary(deadline)
                next_resource_check = time.monotonic() + 5
            remaining = min(37 - (time.monotonic() - begun), deadline - time.monotonic())
            try:
                stdout, stderr = helper.communicate(timeout=max(0, min(1, remaining)))
            except subprocess.TimeoutExpired:
                continue
            check_run_boundary(deadline)
            if time.monotonic() - begun >= 37:
                raise subprocess.TimeoutExpired(command, 37)
            require_resource_bounds(resources())
            check_run_boundary(deadline)
            return subprocess.CompletedProcess(command, helper.returncode, stdout, stderr)
    finally:
        if helper.poll() is None:
            # This exact helper only. subprocess.run already uses this cleanup on
            # its short timeout; never send this signal to Core or another PID.
            helper.kill()
            helper.wait()
            # Discard canceled output: an inherited pipe must not postpone Core
            # shutdown or replace the original resource/stop/deadline failure.
            helper.stdout.close()
            helper.stderr.close()


def rpc(method, *args, guarded_deadline=None):
    assert method in ALLOWED
    if guarded_deadline is not None:
        assert method in {'getblockchaininfo', 'getnetworkinfo', 'getpeerinfo'}
    begun = time.monotonic()
    command = [str(BIN / 'bitcoin-cli'), '-conf=' + str(CONF),
               '-datadir=' + str(DATA), '-rpcconnect=127.0.0.1', '-rpcport=28332',
               '-rpcclienttimeout=' + ('30' if guarded_deadline is not None else '5'),
               method, *map(str, args)]
    result = (guarded_cli_run(command, guarded_deadline) if guarded_deadline is not None
              else subprocess.run(command, capture_output=True, text=True, timeout=12))
    # Never print/log generic stderr: retain only error category/code.
    if result.returncode:
        code = None
        lines = result.stderr.splitlines()
        first = lines[0].strip() if lines else ''
        if first.startswith('error code:'):
            number = first[len('error code:'):].strip()
            if not number and len(lines) > 1:
                number = lines[1].strip()  # Retain compatibility with older fixtures.
            if re.fullmatch(r'-?[0-9]{1,5}', number):
                code = int(number)
        kind = 'CLI_FAILURE_UNCLASSIFIED'
        if code is not None:
            kind = 'RPC_REMOTE_ERROR'
        elif first.startswith('error: timeout on transient error: Could not connect to the server '):
            kind = 'RPC_HTTP_TIMEOUT' if ' - "timeout reached")' in first else 'RPC_CONNECTION_FAILURE'
        elif first == 'error: Authorization failed: Incorrect rpcuser or rpcpassword':
            kind = 'RPC_AUTHORIZATION_FAILED'
        elif first.startswith('error: Could not locate RPC credentials.'):
            kind = 'RPC_CREDENTIALS_UNAVAILABLE'
        return {'ok': False, 'returncode': result.returncode, 'rpc_error_code': code,
                'error_kind': kind, 'elapsed_seconds': round(time.monotonic() - begun, 3)}
    try:
        value = json.loads(result.stdout)
    except json.JSONDecodeError:
        if method == 'getpeerinfo':
            return {'ok': False, 'error_kind': 'INVALID_PEER_DIAGNOSTIC_RESPONSE'}
        value = result.stdout.strip()
    if method == 'getpeerinfo':
        if type(value) is not list:
            return {'ok': False, 'error_kind': 'INVALID_PEER_DIAGNOSTIC_RESPONSE'}
        value = project_peer_diagnostics(value)
    return {'ok': True, 'result': value}


def observe_rpc(method, deadline):
    """At most two read attempts; only an identified HTTP timeout is recoverable."""
    assert method in {'getblockchaininfo', 'getnetworkinfo', 'getpeerinfo'}
    first = rpc(method)
    if first['ok'] or first.get('error_kind') != 'RPC_HTTP_TIMEOUT':
        return first
    event({'stage': 'READ_RPC_HTTP_TIMEOUT', 'method': method, 'failure': first})

    check_run_boundary(deadline)
    resource = resources()
    require_resource_bounds(resource)
    check_run_boundary(deadline)  # Metadata accounting may itself take time.
    cooldown_begun = time.monotonic()
    cooldown_end = cooldown_begun + READ_COOLDOWN_TARGET_SECONDS
    next_resource_check = cooldown_begun + 5
    while time.monotonic() < cooldown_end:
        check_run_boundary(deadline)
        if time.monotonic() >= next_resource_check:
            resource = resources()
            require_resource_bounds(resource)
            check_run_boundary(deadline)
            next_resource_check = time.monotonic() + 5
        remaining = cooldown_end - time.monotonic()
        if remaining > 0:
            time.sleep(min(1, remaining))
    check_run_boundary(deadline)
    resource = resources()
    require_resource_bounds(resource)
    check_run_boundary(deadline)
    event({'stage': 'READ_RPC_SINGLE_RETRY_PREFLIGHT', 'method': method, 'resources': resource,
           'cooldown_target_seconds': READ_COOLDOWN_TARGET_SECONDS,
           'guarded_cooldown_elapsed_seconds': round(time.monotonic() - cooldown_begun, 3)})
    retry = rpc(method, guarded_deadline=deadline)
    return {**retry, 'first_timeout': first, 'attempts': 2}


def stop_owned():
    global NODE
    if NODE is None:
        return {'node_spawned': False}
    result = {'pid': NODE.pid, 'exit_before_stop': NODE.poll()}
    if NODE.poll() is None:
        try:
            result['stop_rpc'] = rpc('stop')
        except Exception as e:
            result['stop_rpc_exception_type'] = type(e).__name__
        try:
            NODE.wait(timeout=45)
        except subprocess.TimeoutExpired:
            # This exact child only, never process-name selection or force kill.
            try:
                NODE.send_signal(signal.SIGINT)
                result['own_child_sigint'] = True
            except OSError as e:
                result['sigint_exception_type'] = type(e).__name__
            # A timeout is a pending shutdown, never permission to abandon the child.
            while NODE.poll() is None:
                try:
                    NODE.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    result['pending_shutdown_waits'] = result.get('pending_shutdown_waits', 0) + 1
                    try:
                        event({'stage': 'SHUTDOWN_PENDING_STILL_SUPERVISED', 'pid': NODE.pid})
                    except OSError:
                        pass  # Failed journaling must not end live-child supervision.
    result['exit_code'] = NODE.poll()
    result['confirmed_exited'] = NODE.poll() is not None
    return result


def request_stop(signum, frame):
    global STOP_REQUEST
    STOP_REQUEST = True


def main():
    global NODE
    mode, segment = sys.argv[1:]
    assert mode in {'offline', 'online'} and segment.isdigit()
    stem = mode + '-' + segment
    assert not (PKG / (stem + '-RESULT.json')).exists(), 'do not overwrite a previous segment'
    assert CONF.is_file() and not CONF.is_symlink()
    for ancestor in [ROOT, *ROOT.parents]:
        assert not ancestor.is_symlink()
    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    begun = time.monotonic()
    result = {'mode': mode, 'segment': int(segment), 'started_at_utc': now(),
              'protocol_state_change': 'NONE', 'sample_chain_verified': False,
              'memory_policy': {'id': 'D199_OWNER_APPROVED_FP2_RSS8_MARGIN64',
                                'footprint_upper_stop_bytes': FOOTPRINT_STOP,
                                'rss_stop_bytes': RSS_STOP,
                                'sampling_is_not_atomic_quota': True},
              'read_retry_policy': {'maximum_attempts': 2, 'HTTP_timeout_only': True,
                                    'guarded_cooldown_target_seconds': READ_COOLDOWN_TARGET_SECONDS,
                                    'first_CLI_timeout_seconds': 5,
                                    'first_subprocess_timeout_seconds': 12,
                                    'guarded_retry_CLI_timeout_seconds': 30,
                                    'guarded_retry_process_timeout_seconds': 37,
                                    'guarded_retry_resource_check_target_seconds': 5}}
    try:
        initial = resources()
        assert max(initial['logical_bytes'], initial['allocated_bytes']) < DIRECTORY_STOP
        assert initial['free_bytes'] > FREE_STOP
        args = [str(BIN / 'bitcoind'), '-conf=' + str(CONF), '-datadir=' + str(DATA),
                '-networkactive=' + ('0' if mode == 'offline' else '1'),
                '-printtoconsole=0', '-nodebuglogfile']
        result['argv'] = args
        NODE = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        result['pid'] = NODE.pid
        event({'stage': 'SPAWNED', 'mode': mode, 'pid': NODE.pid, 'resources': initial})
        ready = False
        while time.monotonic() - begun < 90 and not STOP_REQUEST and NODE.poll() is None:
            status = rpc('getnetworkinfo')
            if status['ok']:
                result['initial_network'] = status
                assert status['result']['networkactive'] is (mode == 'online')
                assert not status['result'].get('localaddresses')
                ready = True
                break
            time.sleep(1)
        if not ready:
            result['status'] = 'RPC_STARTUP_NOT_READY'
            return
        if mode == 'offline':
            assert result['initial_network']['result']['connections'] == 0
            result['initial_chain'] = rpc('getblockchaininfo')
            assert result['initial_chain']['ok']
            result['status'] = 'OFFLINE_PREFLIGHT_PASSED'
            event({'stage': result['status'], 'network': result['initial_network'],
                   'chain': result['initial_chain']})
            return
        next_observation = time.monotonic()
        while not STOP_REQUEST and NODE.poll() is None and time.monotonic() - begun < 3600:
            if time.monotonic() >= next_observation:
                resource = resources()
                result['last_resources_observation'] = resource
                require_resource_bounds(resource)
                chain = observe_rpc('getblockchaininfo', begun + 3600)
                network = observe_rpc('getnetworkinfo', begun + 3600)
                peers = observe_rpc('getpeerinfo', begun + 3600)
                observation = {'stage': 'SYNC_OBSERVATION', 'mode': mode,
                               'resources': resource, 'chain': chain, 'network': network,
                               'peer_diagnostics': peers}
                event(observation)
                save('LIVE_STATUS.json', observation)
                if not chain['ok'] or not network['ok']:
                    result['status'] = 'PUBLIC_RPC_OBSERVATION_FAILED'; break
                info = chain['result']
                result['last_chain'] = chain
                result['last_network'] = network
                result['last_peer_diagnostics'] = peers
                if info['blocks'] >= 912095 and not info['initialblockdownload']:
                    sample_hash = rpc('getblockhash', 912095)
                    result['sample_hash'] = sample_hash
                    assert sample_hash == {'ok': True, 'result': HASH}, 'fixed sample hash mismatch'
                    raw = rpc('getblockheader', HASH, 'false')
                    verbose = rpc('getblockheader', HASH, 'true')
                    result.update(sample_header_raw=raw, sample_header_verbose=verbose)
                    assert raw['ok'] and verbose['ok']
                    header = bytes.fromhex(raw['result'])
                    expected = (Path.cwd() / 'docs/development/mainline-execution-2026-10-19-public-bitcoin-header-rev-001/raw/blockstream-header.hex').read_text().strip()
                    assert len(header) == 80 and raw['result'] == expected
                    assert hashlib.sha256(hashlib.sha256(header).digest()).digest()[::-1].hex() == HASH
                    result['sample_chain_verified'] = True
                    result['status'] = 'PUBLIC_SAMPLE_CORE_OBSERVATION_MATCHED_NOT_PROJECT_STRONG'
                    break
                next_observation = time.monotonic() + 30
            if (PKG / 'STOP_REQUESTED').exists():
                result['status'] = 'SUPERVISOR_STOP_REQUEST'; break
            time.sleep(1)
        result.setdefault('status', 'USER_OR_SIGNAL_STOP' if STOP_REQUEST else
                          'NODE_EXITED' if NODE.poll() is not None else 'SEGMENT_60_MINUTE_BOUND')
    except ObservationStop as e:
        result['status'] = str(e)
    except BaseException as e:
        result.update(status='FAILED', exception_type=type(e).__name__, error=str(e))
        raise
    finally:
        result['shutdown'] = stop_owned()
        result['finished_at_utc'] = now()
        result['elapsed_seconds'] = round(time.monotonic() - begun, 2)
        result['final_resources'] = resources()
        save(stem + '-RESULT.json', result)
        event({'stage': 'SEGMENT_RESULT', **result})


if __name__ == '__main__':
    main()
