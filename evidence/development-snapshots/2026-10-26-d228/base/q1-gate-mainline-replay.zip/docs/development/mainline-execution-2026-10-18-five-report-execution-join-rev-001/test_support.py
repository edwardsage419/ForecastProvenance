"""Fixed keyless synthetic fixtures; no actual report or protocol action."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import ModuleType

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
I = json.loads((HERE / 'INPUTS.json').read_text())
PINS = {r['path']: r['sha256'] for r in I['sources']}


def load(relative, name):
    path = ROOT / relative; raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PINS[relative]:
        raise RuntimeError('Fixed set fixture dependency changed')
    mod = ModuleType(name); mod.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), mod.__dict__)
    return mod


T = load('docs/development/mainline-execution-2026-10-17-r6t-execution-join-rev-001/test_support.py', '_set_execution_fixtures')
OLD = load('docs/development/mainline-execution-2026-10-09-rev-001/report-set-consumption/test_set.py', '_set_old_fixture_functions')
H = T.H
KIND = 'TRUST_CORE_TEST_REPORT'
BTC = 'OTS_BITCOIN_STRONG_VERIFICATION_REPORT'


def assemble(base, statuses=None, verified=True, trust_ids=('CHECK-A', 'CHECK-B')):
    reports = []; catalogs = {}; expected = {}
    for kind in OLD.KINDS:
        T.summarize(base, ids=trust_ids if kind == KIND else ('CHECK-A', 'CHECK-B'),
                    statuses=(statuses or {}).get(kind), kind=kind)
        expected[kind] = deepcopy(base[0]); reports.append({'kind': kind, 'bytes': base[1]})
        catalogs[kind] = {'bytes': base[8], 'sha256': base[9]}
    # Reuse existing synthetic-only Strong fixture, replacing only unit graph refs.
    old = OLD.fixture(verified=verified)
    obj = json.loads(old[1][-1]['bytes'])
    payload = {k: deepcopy(v) for k, v in obj.items()
               if k not in ('object_type', 'object_id', 'payload_sha256', 'content_sha256')}
    vc = base[2]['refs']['vc']; r4t = base[2]['refs']['r4t']
    payload.update(subject_ref=deepcopy(r4t), validator_contract_ref=deepcopy(vc))
    strong = H.seal(payload, 'StrongBitcoinVerificationReport', 'SYNTHETIC-SET-PREBITCOIN')
    raw = H.raw(strong); reports.append({'kind': BTC, 'bytes': raw})
    e = deepcopy(old[0]['prebitcoin_expected'])
    e.update(subject_ref=deepcopy(r4t), validator_contract_ref=deepcopy(vc),
             report_ref=H.ref(strong), report_raw_sha256=H.digest(raw))
    controls = {'format': 'FP_DEV_REQUIRED_REPORT_SET_V1', 'scope': 'FINITE_DEVELOPMENT_SCOPE_ONLY',
                'final_manifest_ref': deepcopy(expected[KIND]['subject_ref']), 'validator_contract_ref': deepcopy(vc),
                'r4t_ref': deepcopy(r4t), 'r4t_raw_sha256': H.digest(base[3]['r4t']),
                'r6_expected': expected, 'prebitcoin_expected': e}
    return [controls, reports, catalogs, *base[2:8], *base[10:14]]


def case(statuses=None, verified=True, trust_ids=('CHECK-A', 'CHECK-B')):
    base, body = T.case()
    return assemble(base, statuses, verified, trust_ids), body


def refresh(args, body, statuses=None):
    base = [None, None, *args[3:9], None, None, *args[9:13]]
    T.rebind(base, body)
    args[:] = assemble(base, statuses)


def row(args, kind=KIND):
    return next(r for r in args[1] if r['kind'] == kind)
