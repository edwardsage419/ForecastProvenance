# D220 同次运行的声明输入身份检查

用户明确恢复同一主线并要求普通阶段连续执行、无需再问批准；99%used（剩1%）保存线有效。保持私钥、真实消息/协议/Git/费用边界。本包直接承接D212与D214，不把它们过往任务的“未接主线”当永久禁令。

确切缺口：D214同次主线只消费D211八锚点；D212单独执行过的63文件加载前检查尚未在本次主线消费。增加同次有限身份检查，完整runtime、真实公共认证和实际规则仍未立。

选择：在现有隔离worker，先以被动reader准入64声明公共输入（63 gate路径+run_binding），复用D214已核相同路径/身份的八快照，拒绝过的路径不重读。只从已pin adapter源码编译其_hash/_pinned/_check_identity、Unresolved及五常量，使用快照_read_regular替代文件访问。既有hash与PRE_RUN逻辑实际运行；不编译或调用native载入/verify函数，不导入ctypes。不是原始文件系统gate环境的重演，也不是任意不可信程序的sandbox。

另一可行做法是再次单跑D212观察脚本，但不会关闭同次消费关系且会重复旧反例，因此排除。复制一份hash/PRE_RUN校验器会分叉验证逻辑，排除。

新GATE_INPUTS.json来自固定D212 READ_SCOPE，以既有64公开文件身份补齐reader所需精确size；它仅是开发有限输入catalog，不是独立全集或权威材料。所有相对路径固定，不扫描目录。新--verifier-gate-inputs只控制该64路径镜像根目录，和原--verifier-inputs九别名独立；显式目录无默认回退。

保留signing_candidates既有两返回值/直接调用行为；只有主线提供gate_output时启用新检查，gate_directory为可选关键字。结果作为initial-authority.result.technical_verifier_identity_gate独立子项，旧两个技术结果不改；任何新硬拒绝传播到父模块/exit2，缺项保留。14模块、10case27input、demo5不变。人类摘要明示63声明gate输入/64准入快照，未执行原生验签、未认证完整运行环境。

出口：真实实现、先RED后GREEN的定向测试、两新进程及完整旧报告投影一致、最多一名独立reviewer及必要定向复验、来源/改动/checkpoint可接续。D211纯4参API、旧adapter/run_binding/PRE_RUN/报告/ZIP及未知dirty均保留。零整项29/11关闭、NOT_READY/NONE。
