"""Exact developer verifier-use content and eight anchors; no verification API."""
import hashlib
from pathlib import Path
from types import ModuleType

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[3]
PACKAGE = ROOT/'docs/development/verifier-contract-consumption-2026-10-25-rev-001'
CONTRACT_RAW = '05fa6b5a9be36a560046c7b2e24b06e4124dce60af7877b28493d076a2120e79'
CONTRACT_REF = {'object_id': 'verifier-contract:initial-ma3:strict-c-dev:v1',
                'content_sha256': '1a2c215289e95f4c2b955468314e05488b8d1dfe2ed20b7562165cccb6e3f160'}


def _fixed(path, digest):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise RuntimeError('D211_FIXED_DEPENDENCY_CHANGED')
    return raw


path = ROOT/'scripts/development/offline_evidence/signing_profile.py'
_P = ModuleType('d211_fixed_profile'); _P.__file__ = str(path)
exec(compile(_fixed(path, 'ea28e595ce0b8d6996ca7dfbf40aa42a60bee19f07cb4755427032e4c74149ff'),
             str(path), 'exec'), _P.__dict__)
_C = _P.canonical
_SCHEMA = _C.parse_json_strict(_fixed(PACKAGE/'CONTRACT_SCHEMA_CANDIDATE.json',
    '08edcb7b2572f8d9d783b6f7079bb6a5f294e0823efa357747a3b419325ef9a5'))
_ARTIFACTS = _C.parse_json_strict(_fixed(PACKAGE/'ARTIFACT_INPUTS.json',
    '475ea94672662aaee9681b0b3e594574a05570b888aa949fc00de7f00232c81a'))
Draft202012Validator.check_schema(_SCHEMA)
_VALIDATOR = Draft202012Validator(_SCHEMA)


def consume(contract_bytes, profile_bytes, rule_bytes=None, artifact_bytes=None):
    """Pure finite comparisons, including the real D189 child; never authenticate.

    Files are admitted at import. This function accepts only supplied bytes and
    does not load the described adapter or dylib. The eight anchors are not the
    existing backend's complete gate/input/runtime closure. Result descriptions
    are content, not observations of a caller's signature or result callback.
    """
    child = _P.consume(profile_bytes, rule_bytes)
    errors, missing = list(child['errors']), list(child['missing'])

    def error(code):
        if code not in errors:
            errors.append(code)

    contract = None
    if contract_bytes is None:
        missing.append('contract_bytes')
    else:
        if (type(contract_bytes) is not bytes or len(contract_bytes) > 1048576
                or hashlib.sha256(contract_bytes).hexdigest() != CONTRACT_RAW):
            error('CONTRACT_RAW_MISMATCH')
        try:
            if type(contract_bytes) is not bytes or len(contract_bytes) > 1048576:
                raise ValueError('bytes/size')
            contract = _C.parse_json_strict(contract_bytes)
            if type(contract) is not dict:
                raise ValueError('object')
        except (ValueError, TypeError, RecursionError):
            error('CONTRACT_JSON_INVALID')
        else:
            if not _VALIDATOR.is_valid(contract):
                error('CONTRACT_SHAPE_INVALID')
            try:
                if not _C.verify_sealed_object(contract):
                    error('CONTRACT_SEAL_INVALID')
            except (ValueError, TypeError, KeyError, RecursionError):
                error('CONTRACT_SEAL_INVALID')
            if contract.get('contract_id') != contract.get('object_id'):
                error('CONTRACT_SEMANTIC_ID_MISMATCH')
            if {key:contract.get(key) for key in CONTRACT_REF} != CONTRACT_REF:
                error('CONTRACT_FULL_REF_MISMATCH')
            if contract.get('profile_ref') != _P.PROFILE_REF:
                error('CONTRACT_PROFILE_REF_MISMATCH')

    if rule_bytes is not None:
        try:
            if type(rule_bytes) is not bytes or len(rule_bytes) > 1048576:
                raise ValueError('bytes/size')
            rule = _C.parse_json_strict(rule_bytes)
            reference = rule['rules']['signing_semantics']['verifier_contract_ref']
        except (ValueError, TypeError, KeyError, RecursionError):
            error('RULE_VERIFIER_USES_INVALID')
        else:
            if reference != CONTRACT_REF:
                error('RULE_VERIFIER_CONTRACT_REF_MISMATCH')

    supplied = {}
    if artifact_bytes is None:
        missing.append('artifact_bytes')
    elif type(artifact_bytes) is not dict:
        error('ARTIFACT_MAPPING_INVALID')
    else:
        supplied = {key:value for key,value in artifact_bytes.items() if type(key) is str}
        if len(supplied) != len(artifact_bytes) or set(supplied)-set(_ARTIFACTS):
            error('ARTIFACT_ROLES_INVALID')
    statuses = {}
    for role, expected in _ARTIFACTS.items():
        raw = supplied.get(role)
        if raw is None:
            missing.append('artifact:'+role)
            status = 'MISSING'
        elif (type(raw) is not bytes or len(raw) != expected['bytes']
                or hashlib.sha256(raw).hexdigest() != expected['sha256']):
            error('ARTIFACT_IDENTITY_MISMATCH:'+role)
            status = 'REJECTED'
        else:
            status = 'OBSERVED'
        statuses[role] = {'status':status, 'expected_bytes':expected['bytes'],
                          'expected_sha256':expected['sha256']}
    contract_ok = contract is not None and not any(e.startswith('CONTRACT_') for e in errors)
    artifact_errors = any(e.startswith('ARTIFACT_') for e in errors)
    artifact_missing = any(s['status'] == 'MISSING' for s in statuses.values())
    artifact_status = 'REJECTED' if artifact_errors else 'MISSING' if artifact_missing else 'OBSERVED'
    matched = contract_ok and not errors and not missing
    return {'scope':'EXACT_D211_CONTRACT_EIGHT_ANCHORS_AND_SUPPLIED_RULE_LOCAL_COMPARISON_ONLY',
            'status':'REJECTED' if errors else 'MISSING' if missing else 'OBSERVED',
            'verdict':'REJECT' if errors else 'UNRESOLVED', 'errors':errors, 'missing':missing,
            'contract_content_status':'OBSERVED' if contract_ok else 'MISSING' if contract_bytes is None else 'REJECTED',
            'contract_ref':dict(CONTRACT_REF) if contract_ok else None,
            'artifact_binding_status':artifact_status, 'artifact_statuses':statuses,
            'profile_result':child,
            'proposed_verifier_use_status':'REJECTED' if errors else 'OBSERVED' if matched else 'MISSING',
            'local_three_signing_uses':'LOCAL_DEVELOPMENT_THREE_USES_MATCHED' if matched else 'NOT_VERIFIED',
            'operational_bindings_established':0,
            'independent_authority_and_applicability':'NOT_ESTABLISHED',
            'effective_boundary':'NOT_ESTABLISHED', 'public_authentication':'NOT_ESTABLISHED',
            'full_build_runtime_closure':'NOT_ESTABLISHED', 'message_resource_policy':'NOT_ESTABLISHED',
            'execution_contract_complete':'NOT_ESTABLISHED',
            'all_source_and_gate_inputs_checked':'NOT_ESTABLISHED',
            'backend_called':False, 'native_loaded':False, 'message_constructed':False, 'carrier_constructed':False,
            'real_admission':'NOT_READY', 'prospective_eligible':False, 'protocol_state_change':'NONE'}
